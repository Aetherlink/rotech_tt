# Enviar telemetría desde Node-RED al API

Tienes dos opciones para alimentar la base de datos:

## Opción A — Seguir escribiendo directo a Postgres (lo que ya haces)
Mantienes tu flujo actual con el nodo `node-red-contrib-postgresql`. Solo asegúrate
de que la tabla coincida con el esquema de Prisma (Prisma la crea con `migrate`).
Las señales NUEVAS que no tengan columna van en la columna JSONB `metrics`:

```sql
INSERT INTO telemetria (vehiculo_id, odometro_km, nivel_combustible, metrics, created_at)
VALUES ($1, $2, $3, $4::jsonb, now());
-- $4 = '{"rpm": 1800, "presion_aceite": 42}'
```

## Opción B — Enviar por HTTP al endpoint de ingesta (recomendado a futuro)
Un nodo `http request` (POST) a `http://TU_SERVIDOR:3000/api/telemetria/ingest`
con este payload. El backend coloca cada señal en su columna si existe, o en `metrics` si es nueva:

```json
{
  "vehiculo": "HK0026",
  "odometro_km": 137723.72,
  "nivel_combustible": 45.2,
  "rpm": 1800,
  "presion_aceite": 42
}
```

Así, cuando llegues a las 20 señales nuevas, NO cambias el backend: solo las mandas
en el JSON y las registras en la pantalla "Señales".

> Protege ese endpoint si lo expones a internet (API key, red privada o reverse proxy).
