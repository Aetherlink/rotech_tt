export interface Usuario {
  id: number; email: string; nombre: string; rol: 'ADMIN' | 'SUPERVISOR' | 'OPERADOR';
  activo?: boolean; createdAt?: string;
}

export interface Vehiculo {
  id: number; codigo: string; placa?: string | null; marca?: string | null;
  modelo?: string | null; anio?: number | null; color?: string | null;
  tipoOdometro?: string | null; capacidadTanque?: number | null;
  estadoAdmin: 'OPERATIVO' | 'BAJA'; observaciones?: string | null;
}

export interface Senal {
  id: number; clave: string; etiqueta: string; unidad?: string | null;
  tipo: 'NUMERICO' | 'BOOLEANO' | 'TEXTO' | 'ENUM'; categoria: string;
  icono?: string | null; color?: string | null; decimales: number;
  minimo?: number | null; maximo?: number | null; umbralAlerta?: number | null;
  agregable: boolean; activo: boolean; orden: number;
}

export interface Material {
  id?: number; nombre: string; tipo: string | null;
  cantidad: number | null; unidad: string; observacion: string;
}

export interface PlanMantenimiento {
  id: number; vehiculoId: number; nombre: string; categoria: string;
  descripcion?: string | null; nivelUrgencia: string; tipoPeriodicidad: string;
  activo: boolean; vehiculo?: { codigo: string; placa?: string | null };
}

export interface ProximoMantenimiento {
  id: number; vehiculoId: number; placa: string; codigo: string; nombre: string;
  urgencia: string; fechaEstimada: string | null; vencido: boolean;
}

export interface RangoFechas { desde: string; hasta: string; }
