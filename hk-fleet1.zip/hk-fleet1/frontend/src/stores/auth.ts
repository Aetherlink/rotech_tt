import { defineStore } from 'pinia';
import api from '@/services/api';
import type { Usuario } from '@/types';

export const useAuthStore = defineStore('auth', {
  state: () => ({
    token: localStorage.getItem('token') as string | null,
    usuario: JSON.parse(localStorage.getItem('usuario') || 'null') as Usuario | null,
  }),
  getters: {
    autenticado: (s) => !!s.token,
    esAdmin: (s) => s.usuario?.rol === 'ADMIN',
    // Solo ADMIN crea/edita activos. ADMIN y SUPERVISOR gestionan planes.
    puedeGestionarActivos: (s) => s.usuario?.rol === 'ADMIN',
    puedeGestionarPlanes: (s) => ['ADMIN', 'SUPERVISOR'].includes(s.usuario?.rol || ''),
  },
  actions: {
    async login(email: string, password: string) {
      const { data } = await api.post('/auth/login', { email, password });
      this.token = data.token;
      this.usuario = data.usuario;
      localStorage.setItem('token', data.token);
      localStorage.setItem('usuario', JSON.stringify(data.usuario));
    },
    logout() {
      this.token = null; this.usuario = null;
      localStorage.removeItem('token'); localStorage.removeItem('usuario');
    },
  },
});
