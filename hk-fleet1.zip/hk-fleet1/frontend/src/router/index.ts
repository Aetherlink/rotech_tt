import { createRouter, createWebHistory } from 'vue-router';
import { useAuthStore } from '@/stores/auth';

const routes = [
  { path: '/login', name: 'login', component: () => import('@/views/LoginView.vue'), meta: { publica: true } },
  {
    path: '/',
    component: () => import('@/layouts/DashboardLayout.vue'),
    children: [
      { path: '', name: 'dashboard', component: () => import('@/views/DashboardView.vue') },
      { path: 'vehiculos', name: 'vehiculos', component: () => import('@/views/VehiculosView.vue') },
      { path: 'vehiculos/:id', name: 'vehiculo-detalle', component: () => import('@/views/VehiculoDetailView.vue') },
      { path: 'planes', name: 'planes', component: () => import('@/views/PlanesView.vue') },
      { path: 'senales', name: 'senales', component: () => import('@/views/SenalesView.vue'), meta: { soloAdmin: true } },
      { path: 'usuarios', name: 'usuarios', component: () => import('@/views/UsuariosView.vue'), meta: { soloAdmin: true } },
    ],
  },
];

const router = createRouter({ history: createWebHistory(), routes });

router.beforeEach((to) => {
  const auth = useAuthStore();
  if (!to.meta.publica && !auth.autenticado) return { name: 'login' };
  if (to.meta.publica && auth.autenticado) return { name: 'dashboard' };
  if (to.meta.soloAdmin && !auth.esAdmin) return { name: 'dashboard' };
});

export default router;
