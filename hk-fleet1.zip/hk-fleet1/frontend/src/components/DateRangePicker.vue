<script setup lang="ts">
import { ref, watch } from 'vue';

// Emite { desde, hasta } en formato YYYY-MM-DD. Por defecto: últimos 7 días.
const emit = defineEmits<{ cambio: [{ desde: string; hasta: string }] }>();
const props = defineProps<{ dias?: number }>();

const fmt = (d: Date) => d.toISOString().slice(0, 10);
function preset(dias: number) {
  const hasta = new Date();
  const desde = new Date(hasta.getTime() - (dias - 1) * 864e5);
  return { desde: fmt(desde), hasta: fmt(hasta) };
}

const rango = ref(preset(props.dias ?? 7));
const menu = ref(false);

function aplicarPreset(dias: number) {
  rango.value = preset(dias);
  menu.value = false;
}

watch(rango, (v) => emit('cambio', { ...v }), { immediate: true, deep: true });
</script>

<template>
  <div class="d-flex align-center ga-2 flex-wrap">
    <v-btn-toggle density="comfortable" variant="outlined" divided>
      <v-btn size="small" @click="aplicarPreset(7)">Semana</v-btn>
      <v-btn size="small" @click="aplicarPreset(30)">Mes</v-btn>
    </v-btn-toggle>

    <v-menu v-model="menu" :close-on-content-click="false" location="bottom end">
      <template #activator="{ props: p }">
        <v-btn v-bind="p" size="small" variant="outlined" prepend-icon="mdi-calendar">
          {{ rango.desde }} → {{ rango.hasta }}
        </v-btn>
      </template>
      <v-card min-width="300" class="pa-4">
        <v-label class="font-weight-bold mb-1">Desde</v-label>
        <v-text-field v-model="rango.desde" type="date" density="compact" class="mb-3" />
        <v-label class="font-weight-bold mb-1">Hasta</v-label>
        <v-text-field v-model="rango.hasta" type="date" density="compact" />
        <v-btn color="primary" block class="mt-3" @click="menu = false">Aplicar</v-btn>
      </v-card>
    </v-menu>
  </div>
</template>
