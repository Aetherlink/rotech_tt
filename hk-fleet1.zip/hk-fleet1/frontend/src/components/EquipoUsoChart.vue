<script setup lang="ts">
import { ref, watch, computed } from 'vue';
import api from '@/services/api';
import DateRangePicker from '@/components/DateRangePicker.vue';

// Reutilizable para los dos charts del detalle del equipo.
// modo='uso'  -> barras apiladas (movimiento/ralentí/apagado)
// modo='motor'-> barras simples de horas de motor por día.
const props = defineProps<{ codigo: string; modo: 'uso' | 'motor'; titulo: string }>();

const serie = ref<any[]>([]);
const cargando = ref(false);
let rangoActual = { desde: '', hasta: '' };

async function cargar() {
  if (!rangoActual.desde) return;
  cargando.value = true;
  try {
    const url = props.modo === 'uso'
      ? `/analytics/uso-equipo/${props.codigo}`
      : `/analytics/motor-encendido/${props.codigo}`;
    const { data } = await api.get(url, { params: rangoActual });
    serie.value = data.serie;
  } finally { cargando.value = false; }
}
function onRango(r: { desde: string; hasta: string }) { rangoActual = r; cargar(); }
watch(() => props.codigo, cargar);

const categorias = computed(() => serie.value.map((p) => p.dia.slice(5)));

const series = computed(() => props.modo === 'uso'
  ? [
      { name: 'Encendido en movimiento', data: serie.value.map((p) => p.movimiento) },
      { name: 'Encendido sin movimiento', data: serie.value.map((p) => p.ralenti) },
      { name: 'Tiempo apagado', data: serie.value.map((p) => p.apagado) },
    ]
  : [{ name: 'Horas motor', data: serie.value.map((p) => p.valor) }]);

const options = computed(() => ({
  chart: { type: 'bar', height: 320, fontFamily: 'inherit', foreColor: '#a1aab2',
           stacked: props.modo === 'uso', toolbar: { show: false } },
  colors: props.modo === 'uso' ? ['#13DEB9', '#49BEFF', '#FA896B'] : ['#5D87FF'],
  plotOptions: { bar: { borderRadius: 4, columnWidth: '45%' } },
  dataLabels: { enabled: false },
  legend: { show: props.modo === 'uso', position: 'right' },
  xaxis: { categories: categorias.value },
  yaxis: { max: props.modo === 'uso' ? 24 : undefined, title: { text: 'horas' } },
  grid: { borderColor: '#E5EAEF', strokeDashArray: 4 },
  tooltip: { theme: 'light', y: { formatter: (v: number) => `${v} h` } },
}));
</script>

<template>
  <v-card>
    <v-card-item>
      <div class="d-flex align-center justify-space-between flex-wrap ga-2">
        <v-card-title class="text-h6">{{ titulo }}</v-card-title>
        <DateRangePicker @cambio="onRango" />
      </div>
    </v-card-item>
    <v-card-text>
      <v-progress-linear v-if="cargando" indeterminate color="primary" class="mb-2" />
      <apexchart type="bar" height="320" :options="options" :series="series" />
    </v-card-text>
  </v-card>
</template>
