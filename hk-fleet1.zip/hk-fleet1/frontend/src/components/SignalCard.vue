<script setup lang="ts">
import { computed } from 'vue';
import type { Senal } from '@/types';

// Componente-plantilla: recibe la DEFINICIÓN de la señal + su valor actual
// y se pinta solo. Sirve para cualquier señal presente o futura sin tocar
// este código: ícono, unidad, color y umbral de alerta vienen de la metadata.
const props = defineProps<{ senal: Senal; valor: number | boolean | null }>();

const enAlerta = computed(() => {
  if (props.senal.umbralAlerta == null || typeof props.valor !== 'number') return false;
  return props.valor >= props.senal.umbralAlerta;
});

const textoValor = computed(() => {
  if (props.valor == null) return '—';
  if (props.senal.tipo === 'BOOLEANO') return props.valor ? 'Sí' : 'No';
  if (typeof props.valor === 'number') return props.valor.toFixed(props.senal.decimales);
  return String(props.valor);
});

const acento = computed(() => props.senal.color || 'rgb(var(--v-theme-primary))');
</script>

<template>
  <v-card :class="{ 'border-error': enAlerta }" class="h-100">
    <v-card-text class="d-flex align-center ga-4">
      <v-avatar :color="enAlerta ? 'error' : undefined" rounded="lg" size="52"
                :style="!enAlerta ? `background:${acento}1A` : ''">
        <v-icon :color="enAlerta ? 'white' : undefined" :style="!enAlerta ? `color:${acento}` : ''" size="26">
          {{ senal.icono || 'mdi-chart-line' }}
        </v-icon>
      </v-avatar>
      <div>
        <p class="text-medium-emphasis text-body-2 mb-1">{{ senal.etiqueta }}</p>
        <div class="d-flex align-baseline ga-1">
          <span class="text-h5 font-weight-bold">{{ textoValor }}</span>
          <span v-if="senal.unidad && valor != null" class="text-body-2 text-medium-emphasis">
            {{ senal.unidad }}
          </span>
        </div>
      </div>
      <v-spacer />
      <v-tooltip v-if="enAlerta" text="Supera el umbral de alerta" location="top">
        <template #activator="{ props: tp }">
          <v-icon v-bind="tp" color="error">mdi-alert-circle</v-icon>
        </template>
      </v-tooltip>
    </v-card-text>
  </v-card>
</template>
