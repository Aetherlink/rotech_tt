<script setup lang="ts">
import { computed } from 'vue';

// Tarjeta tipo Modernize: título, total grande, variación % y gráfico de área.
const props = defineProps<{
  titulo: string;
  total: number;
  unidad: string;
  variacion?: number | null;     // % vs periodo anterior
  serie: { dia: string; valor: number }[];
  color?: string;
}>();

const acento = computed(() => props.color || '#5D87FF');
const categorias = computed(() => props.serie.map((p) => p.dia));
const datos = computed(() => props.serie.map((p) => p.valor));

const options = computed(() => ({
  chart: { type: 'area', height: 300, fontFamily: 'inherit', foreColor: '#a1aab2', toolbar: { show: false }, zoom: { enabled: false } },
  colors: [acento.value],
  dataLabels: { enabled: false },
  stroke: { curve: 'smooth', width: 2 },
  fill: { type: 'gradient', gradient: { opacityFrom: 0.35, opacityTo: 0.05 } },
  markers: { size: 0 },
  xaxis: { categories: categorias.value, labels: { format: undefined }, axisBorder: { show: false } },
  yaxis: { opposite: true },
  grid: { borderColor: '#E5EAEF', strokeDashArray: 4 },
  tooltip: { theme: 'light' },
}));
const series = computed(() => [{ name: props.unidad, data: datos.value }]);

const variacionPositiva = computed(() => (props.variacion ?? 0) >= 0);
</script>

<template>
  <v-card class="h-100">
    <v-card-item>
      <v-card-title class="text-h6">{{ titulo }}</v-card-title>
      <div class="mt-2">
        <h3 class="text-h4 font-weight-bold">
          {{ total.toLocaleString('es-EC') }}<span class="text-h6 text-medium-emphasis ml-1">{{ unidad }}</span>
        </h3>
        <div v-if="variacion != null" class="mt-1 d-flex align-center">
          <v-avatar :color="variacionPositiva ? '#13DEB91A' : '#FA896B1A'" size="24">
            <v-icon :color="variacionPositiva ? 'success' : 'error'" size="18">
              {{ variacionPositiva ? 'mdi-arrow-top-right' : 'mdi-arrow-bottom-right' }}
            </v-icon>
          </v-avatar>
          <span class="text-subtitle-2 font-weight-bold ml-2">{{ variacionPositiva ? '+' : '' }}{{ variacion }}%</span>
          <span class="text-subtitle-2 text-medium-emphasis ml-2">vs. periodo anterior</span>
        </div>
      </div>
    </v-card-item>
    <div class="mt-2">
      <apexchart type="area" height="300" :options="options" :series="series" />
    </div>
  </v-card>
</template>
