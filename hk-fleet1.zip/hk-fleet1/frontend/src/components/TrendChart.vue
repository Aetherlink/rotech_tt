<script setup lang="ts">
import { ref, watch, computed } from 'vue';
import api from '@/services/api';
import type { Senal } from '@/types';

// Componente-plantilla de gráfico: dado un vehículo + una señal, pide la serie
// temporal al backend y la grafica. Funciona con cualquier señal (columna o JSON).
const props = defineProps<{ codigo: string; senal: Senal; limite?: number }>();

const serie = ref<{ x: number; y: number | null }[]>([]);
const cargando = ref(false);

async function cargar() {
  cargando.value = true;
  try {
    const { data } = await api.get(`/telemetria/${props.codigo}/serie`, {
      params: { senal: props.senal.clave, limite: props.limite || 200 },
    });
    serie.value = data.serie.map((p: any) => ({ x: new Date(p.t).getTime(), y: p.v }));
  } finally {
    cargando.value = false;
  }
}

watch(() => [props.codigo, props.senal.clave], cargar, { immediate: true });

const series = computed(() => [{ name: props.senal.etiqueta, data: serie.value }]);
const options = computed(() => ({
  chart: { type: 'area', toolbar: { show: false }, fontFamily: 'inherit', sparkline: { enabled: false } },
  colors: [props.senal.color || '#5D87FF'],
  stroke: { curve: 'smooth', width: 2 },
  fill: { type: 'gradient', gradient: { opacityFrom: 0.4, opacityTo: 0.05 } },
  dataLabels: { enabled: false },
  xaxis: { type: 'datetime', labels: { datetimeUTC: false } },
  yaxis: { labels: { formatter: (v: number) => v?.toFixed(props.senal.decimales) } },
  tooltip: { x: { format: 'dd MMM HH:mm' } },
  grid: { borderColor: '#E5EAEF', strokeDashArray: 4 },
}));
</script>

<template>
  <v-card>
    <v-card-title class="d-flex align-center text-subtitle-1 font-weight-bold">
      {{ senal.etiqueta }}
      <span v-if="senal.unidad" class="text-medium-emphasis text-body-2 ml-1">({{ senal.unidad }})</span>
      <v-spacer />
      <v-btn icon="mdi-refresh" size="small" variant="text" @click="cargar" />
    </v-card-title>
    <v-card-text>
      <v-progress-linear v-if="cargando" indeterminate color="primary" class="mb-2" />
      <apexchart type="area" height="260" :options="options" :series="series" />
    </v-card-text>
  </v-card>
</template>
