<script setup lang="ts">
import type { ProximoMantenimiento } from '@/types';

defineProps<{ items: ProximoMantenimiento[]; cargando?: boolean }>();

// Mapea el nivel de urgencia del plan a etiqueta/color de prioridad (como Modernize).
const prioridad: Record<string, { label: string; color: string }> = {
  BAJA: { label: 'Low', color: 'success' },
  MEDIA: { label: 'Medium', color: 'info' },
  ALTA: { label: 'High', color: 'secondary' },
  CRITICA: { label: 'Critical', color: 'error' },
};

function fecha(d: string | null) {
  if (!d) return 'Sin estimar';
  const f = new Date(d);
  return `${String(f.getDate()).padStart(2, '0')}-${String(f.getMonth() + 1).padStart(2, '0')}-${String(f.getFullYear()).slice(2)}`;
}
</script>

<template>
  <v-card class="h-100">
    <v-card-item>
      <v-card-title class="text-h6">Próximos mantenimientos</v-card-title>
    </v-card-item>
    <v-card-text>
      <v-table>
        <thead>
          <tr class="text-medium-emphasis">
            <th>Placa</th><th>Mantenimiento</th><th>Prioridad</th><th class="text-right">Fecha estimada</th>
          </tr>
        </thead>
        <tbody>
          <tr v-if="cargando"><td colspan="4" class="text-center py-4">
            <v-progress-circular indeterminate color="primary" size="24" /></td></tr>
          <tr v-else-if="!items.length"><td colspan="4" class="text-center text-medium-emphasis py-4">
            Sin mantenimientos próximos</td></tr>
          <tr v-for="m in items" :key="m.id">
            <td class="font-weight-bold">{{ m.placa }}</td>
            <td class="text-primary">{{ m.nombre }}</td>
            <td>
              <v-chip :color="prioridad[m.urgencia]?.color" size="small" variant="flat" class="text-white">
                {{ prioridad[m.urgencia]?.label || m.urgencia }}
              </v-chip>
            </td>
            <td class="text-right font-weight-bold">
              <v-icon v-if="m.vencido" color="error" size="16" class="mr-1">mdi-alert</v-icon>
              {{ fecha(m.fechaEstimada) }}
            </td>
          </tr>
        </tbody>
      </v-table>
    </v-card-text>
  </v-card>
</template>
