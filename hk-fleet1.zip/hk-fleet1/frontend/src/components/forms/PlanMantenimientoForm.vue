<script setup lang="ts">
import { ref, reactive, computed, onMounted } from 'vue';
import api from '@/services/api';
import type { Vehiculo, Material } from '@/types';

const emit = defineEmits<{ guardado: [any]; cancelar: [] }>();

const categorias = ['Motor', 'Frenos', 'Transmision', 'Sistema electrico', 'Llantas y neumaticos',
  'Sistema de enfriamiento', 'Sistema hidraulico', 'Sistema de escape', 'Lubricacion', 'Filtros',
  'Bateria', 'Correas y cadenas', 'Revision general', 'Otro'];

// Corregido: sin el objeto vacío y con horometro_tiempo presente.
const tiposPeriodicidad = [
  { title: 'Por Horómetro (horas)', value: 'HOROMETRO' },
  { title: 'Por Odómetro (km/mi)', value: 'ODOMETRO' },
  { title: 'Por Tiempo (días)', value: 'TIEMPO' },
  { title: 'Horómetro + Tiempo (lo que ocurra primero)', value: 'HOROMETRO_TIEMPO' },
  { title: 'Odómetro + Tiempo (lo que ocurra primero)', value: 'ODOMETRO_TIEMPO' },
];
const unidadesTiempo = ['Dias', 'Semanas', 'Meses', 'Anos'];
const unidadesMantenimiento = ['Horas', 'Minutos', 'Dias'];
const tiposMaterial = ['Lubricante / Aceite', 'Filtro', 'Correa / Cadena', 'Neumatico / Llanta',
  'Liquido refrigerante', 'Liquido de frenos', 'Bujia', 'Repuesto electrico',
  'Herramienta especializada', 'Insumo de limpieza', 'Otro'];
const nivelesUrgencia = [
  { title: 'Baja - Solo informativa', value: 'BAJA', color: 'success' },
  { title: 'Media - Planificar pronto', value: 'MEDIA', color: 'info' },
  { title: 'Alta - Atender urgente', value: 'ALTA', color: 'warning' },
  { title: 'Crítica - Detener equipo', value: 'CRITICA', color: 'error' },
];

const vehiculos = ref<Vehiculo[]>([]);
onMounted(async () => { vehiculos.value = (await api.get('/vehiculos')).data; });

const form = reactive<any>({
  vehiculoId: null, nombre: '', categoria: null, descripcion: '',
  tipoPeriodicidad: null, intervaloHorometro: null, intervaloOdometro: null,
  intervaloDias: null, unidadTiempo: 'Dias',
  alertaHorometro: null, alertaOdometro: null, alertaDias: null, nivelUrgencia: 'MEDIA',
  tiempoEstimado: null, unidadTiempoEstimado: 'Horas', personalRequerido: null, perfilPersonal: '',
  materiales: [] as Material[], pasos: '', requiereDetenerEquipo: true, requiereEspecialista: false,
  activo: true, observaciones: '',
});

let materialId = 0;
const mostrarHorometro = computed(() => ['HOROMETRO', 'HOROMETRO_TIEMPO'].includes(form.tipoPeriodicidad));
const mostrarOdometro = computed(() => ['ODOMETRO', 'ODOMETRO_TIEMPO'].includes(form.tipoPeriodicidad));
const mostrarTiempo = computed(() => ['TIEMPO', 'HOROMETRO_TIEMPO', 'ODOMETRO_TIEMPO'].includes(form.tipoPeriodicidad));

function agregarMaterial() {
  form.materiales.push({ id: ++materialId, nombre: '', tipo: null, cantidad: null, unidad: 'Unidades', observacion: '' });
}
function eliminarMaterial(id: number) {
  const i = form.materiales.findIndex((m: any) => m.id === id);
  if (i !== -1) form.materiales.splice(i, 1);
}

const loading = ref(false);
const error = ref('');
const formRef = ref<any>(null);
const rules = {
  required: (v: any) => !!v || 'Este campo es requerido',
  positivo: (v: number) => !v || v > 0 || 'Debe ser mayor a 0',
  positivoOCero: (v: number) => v == null || v >= 0 || 'Debe ser positivo',
};

async function guardar() {
  const { valid } = await formRef.value.validate();
  if (!valid) return;
  if (!form.intervaloHorometro && !form.intervaloOdometro && !form.intervaloDias) {
    error.value = 'Define al menos un intervalo de periodicidad.'; return;
  }
  loading.value = true; error.value = '';
  try {
    const payload = { ...form, materiales: form.materiales.map(({ id, ...m }: any) => m) };
    const { data } = await api.post('/planes', payload);
    emit('guardado', data);
  } catch (e: any) {
    error.value = e.response?.data?.error || 'Error al guardar el plan';
  } finally { loading.value = false; }
}
</script>

<template>
  <v-form ref="formRef" @submit.prevent="guardar">
    <v-alert v-if="error" type="error" variant="tonal" density="compact" class="mb-4">{{ error }}</v-alert>
    <v-row>
      <!-- Vehículo + identificación -->
      <v-col cols="12"><p class="text-subtitle-1 font-weight-bold text-primary mb-1">Vehículo y plan</p>
        <v-divider class="mb-3" /></v-col>
      <v-col cols="12" md="4">
        <v-label class="font-weight-bold mb-1">Vehículo <span class="text-error">*</span></v-label>
        <v-select v-model="form.vehiculoId" :items="vehiculos" item-value="id" :rules="[rules.required]"
                  :item-title="(v) => `${v.codigo} · ${v.placa || ''}`" placeholder="Selecciona" />
      </v-col>
      <v-col cols="12" md="5">
        <v-label class="font-weight-bold mb-1">Nombre del mantenimiento <span class="text-error">*</span></v-label>
        <v-text-field v-model="form.nombre" placeholder="ej: Cambio de aceite y filtro" :rules="[rules.required]" />
      </v-col>
      <v-col cols="12" md="3">
        <v-label class="font-weight-bold mb-1">Categoría <span class="text-error">*</span></v-label>
        <v-select v-model="form.categoria" :items="categorias" :rules="[rules.required]" />
      </v-col>
      <v-col cols="12">
        <v-label class="font-weight-bold mb-1">Descripción</v-label>
        <v-textarea v-model="form.descripcion" rows="2" placeholder="En qué consiste este mantenimiento..." />
      </v-col>
      <v-col cols="12" md="6">
        <v-checkbox v-model="form.requiereDetenerEquipo" label="Requiere detener el equipo" color="warning" hide-details />
      </v-col>
      <v-col cols="12" md="6">
        <v-checkbox v-model="form.requiereEspecialista" label="Requiere técnico especialista externo" color="info" hide-details />
      </v-col>

      <!-- Periodicidad -->
      <v-col cols="12" class="mt-2"><p class="text-subtitle-1 font-weight-bold text-primary mb-1">Periodicidad y alertas</p>
        <v-divider class="mb-3" /></v-col>
      <v-col cols="12">
        <v-label class="font-weight-bold mb-1">Tipo de periodicidad <span class="text-error">*</span></v-label>
        <v-select v-model="form.tipoPeriodicidad" :items="tiposPeriodicidad" item-title="title" item-value="value"
                  :rules="[rules.required]" />
      </v-col>
      <template v-if="mostrarHorometro">
        <v-col cols="12" md="6"><v-label class="font-weight-bold mb-1">Intervalo de horómetro <span class="text-error">*</span></v-label>
          <v-text-field v-model.number="form.intervaloHorometro" type="number" suffix="h" :rules="[rules.required, rules.positivo]" /></v-col>
        <v-col cols="12" md="6"><v-label class="font-weight-bold mb-1">Alertar cuando falten (h)</v-label>
          <v-text-field v-model.number="form.alertaHorometro" type="number" suffix="h" :rules="[rules.positivoOCero]" /></v-col>
      </template>
      <template v-if="mostrarOdometro">
        <v-col cols="12" md="6"><v-label class="font-weight-bold mb-1">Intervalo de odómetro <span class="text-error">*</span></v-label>
          <v-text-field v-model.number="form.intervaloOdometro" type="number" suffix="km" :rules="[rules.required, rules.positivo]" /></v-col>
        <v-col cols="12" md="6"><v-label class="font-weight-bold mb-1">Alertar cuando falten (km)</v-label>
          <v-text-field v-model.number="form.alertaOdometro" type="number" suffix="km" :rules="[rules.positivoOCero]" /></v-col>
      </template>
      <template v-if="mostrarTiempo">
        <v-col cols="6" md="3"><v-label class="font-weight-bold mb-1">Intervalo de tiempo <span class="text-error">*</span></v-label>
          <v-text-field v-model.number="form.intervaloDias" type="number" :rules="[rules.required, rules.positivo]" /></v-col>
        <v-col cols="6" md="3"><v-label class="font-weight-bold mb-1">Unidad</v-label>
          <v-select v-model="form.unidadTiempo" :items="unidadesTiempo" /></v-col>
        <v-col cols="12" md="6"><v-label class="font-weight-bold mb-1">Alertar cuando falten (días)</v-label>
          <v-text-field v-model.number="form.alertaDias" type="number" suffix="días" :rules="[rules.positivoOCero]" /></v-col>
      </template>
      <v-col cols="12">
        <v-label class="font-weight-bold mb-1">Nivel de urgencia al activarse <span class="text-error">*</span></v-label>
        <v-select v-model="form.nivelUrgencia" :items="nivelesUrgencia" item-title="title" item-value="value" :rules="[rules.required]">
          <template #item="{ item, props: ip }">
            <v-list-item v-bind="ip"><template #prepend><v-icon :color="item.raw.color">mdi-circle</v-icon></template></v-list-item>
          </template>
        </v-select>
      </v-col>

      <!-- Ejecución -->
      <v-col cols="12" class="mt-2"><p class="text-subtitle-1 font-weight-bold text-primary mb-1">Datos de ejecución</p>
        <v-divider class="mb-3" /></v-col>
      <v-col cols="12" md="4"><v-label class="font-weight-bold mb-1">Tiempo estimado</v-label>
        <v-text-field v-model.number="form.tiempoEstimado" type="number" :rules="[rules.positivo]" /></v-col>
      <v-col cols="12" md="4"><v-label class="font-weight-bold mb-1">Unidad de tiempo</v-label>
        <v-select v-model="form.unidadTiempoEstimado" :items="unidadesMantenimiento" /></v-col>
      <v-col cols="12" md="4"><v-label class="font-weight-bold mb-1">Cantidad de personas</v-label>
        <v-text-field v-model.number="form.personalRequerido" type="number" :rules="[rules.positivo]" /></v-col>
      <v-col cols="12"><v-label class="font-weight-bold mb-1">Perfil del personal requerido</v-label>
        <v-text-field v-model="form.perfilPersonal" placeholder="ej: Mecánico certificado nivel 2" /></v-col>

      <!-- Materiales -->
      <v-col cols="12" class="mt-2">
        <div class="d-flex align-center justify-space-between">
          <p class="text-subtitle-1 font-weight-bold text-primary mb-1">Materiales y repuestos</p>
          <v-btn size="small" color="primary" variant="tonal" prepend-icon="mdi-plus" @click="agregarMaterial">Agregar</v-btn>
        </div>
        <v-divider class="mb-3 mt-1" />
      </v-col>
      <v-col v-if="!form.materiales.length" cols="12">
        <v-alert type="info" variant="tonal" density="compact">Aún no hay materiales. Usa "Agregar".</v-alert>
      </v-col>
      <v-col v-for="m in form.materiales" :key="m.id" cols="12">
        <v-card variant="outlined" class="pa-3"><v-row dense>
          <v-col cols="12" md="4"><v-label class="font-weight-bold mb-1">Nombre <span class="text-error">*</span></v-label>
            <v-text-field v-model="m.nombre" density="compact" placeholder="ej: Aceite 15W40" :rules="[rules.required]" /></v-col>
          <v-col cols="12" md="3"><v-label class="font-weight-bold mb-1">Tipo</v-label>
            <v-select v-model="m.tipo" :items="tiposMaterial" density="compact" /></v-col>
          <v-col cols="6" md="2"><v-label class="font-weight-bold mb-1">Cantidad</v-label>
            <v-text-field v-model.number="m.cantidad" type="number" density="compact" :rules="[rules.positivo]" /></v-col>
          <v-col cols="6" md="2"><v-label class="font-weight-bold mb-1">Unidad</v-label>
            <v-text-field v-model="m.unidad" density="compact" /></v-col>
          <v-col cols="12" md="1" class="d-flex align-end justify-center">
            <v-btn icon="mdi-delete" color="error" variant="text" density="compact" @click="eliminarMaterial(m.id)" /></v-col>
          <v-col cols="12"><v-text-field v-model="m.observacion" density="compact"
            placeholder="Observación (marca, referencia, etc.)" /></v-col>
        </v-row></v-card>
      </v-col>

      <!-- Procedimiento -->
      <v-col cols="12" class="mt-2"><p class="text-subtitle-1 font-weight-bold text-primary mb-1">Procedimiento</p>
        <v-divider class="mb-3" /></v-col>
      <v-col cols="12"><v-label class="font-weight-bold mb-1">Pasos del procedimiento</v-label>
        <v-textarea v-model="form.pasos" rows="4" placeholder="1. Apagar el equipo...&#10;2. Drenar el aceite..." /></v-col>
      <v-col cols="12"><v-label class="font-weight-bold mb-1">Observaciones generales</v-label>
        <v-textarea v-model="form.observaciones" rows="2" /></v-col>
      <v-col cols="12"><v-switch v-model="form.activo" label="Plan activo" color="success" inset hide-details /></v-col>

      <v-col cols="12" md="6"><v-btn variant="outlined" size="large" block color="secondary"
        @click="emit('cancelar')">Cancelar</v-btn></v-col>
      <v-col cols="12" md="6"><v-btn type="submit" color="primary" size="large" block :loading="loading">
        Guardar plan</v-btn></v-col>
    </v-row>
  </v-form>
</template>
