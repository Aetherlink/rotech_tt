<script setup lang="ts">
import { ref, reactive, watch } from 'vue';
import api from '@/services/api';
import type { Vehiculo } from '@/types';

const props = defineProps<{ modelValue?: Partial<Vehiculo> | null }>();
const emit = defineEmits<{ guardado: [Vehiculo]; cancelar: [] }>();

const tiposOdometro = ['Kilometros', 'Millas'];
const estados = [{ title: 'Operativo', value: 'OPERATIVO' }, { title: 'De baja', value: 'BAJA' }];

const form = reactive<any>({
  codigo: '', placa: '', marca: '', modelo: '', anio: null, color: '',
  tipoOdometro: 'Kilometros', capacidadTanque: null, estadoAdmin: 'OPERATIVO', observaciones: '',
});
watch(() => props.modelValue, (v) => { if (v) Object.assign(form, v); }, { immediate: true });

const loading = ref(false);
const error = ref('');
const formRef = ref<any>(null);
const rules = {
  required: (v: any) => !!v || 'Este campo es requerido',
  placa: (v: string) => !v ||
    /^[A-Z]{2,3}[-]?[0-9]{3,4}$|^[A-Z]{3}[0-9]{2}[A-Z]$/.test(v?.toUpperCase()) || 'Formato de placa inválido',
  anio: (v: number) => { if (!v) return true; const y = new Date().getFullYear();
    return (v >= 1900 && v <= y + 1) || `Año entre 1900 y ${y + 1}`; },
};

async function guardar() {
  const { valid } = await formRef.value.validate();
  if (!valid) return;
  loading.value = true; error.value = '';
  try {
    const payload = { ...form, codigo: form.codigo.toUpperCase(), placa: form.placa?.toUpperCase() || null };
    const { data } = form.id ? await api.put(`/vehiculos/${form.id}`, payload) : await api.post('/vehiculos', payload);
    emit('guardado', data);
  } catch (e: any) {
    error.value = e.response?.data?.error || 'Error al guardar';
  } finally { loading.value = false; }
}
</script>

<template>
  <v-form ref="formRef" @submit.prevent="guardar">
    <v-alert v-if="error" type="error" variant="tonal" density="compact" class="mb-4">{{ error }}</v-alert>
    <v-row>
      <v-col cols="12">
        <p class="text-subtitle-1 font-weight-bold text-primary mb-1">Identificación</p>
        <v-divider class="mb-3" />
      </v-col>
      <v-col cols="12" md="6">
        <v-label class="font-weight-bold mb-1">Código / ID <span class="text-error">*</span></v-label>
        <v-text-field v-model="form.codigo" placeholder="ej: HK0026" :rules="[rules.required]"
                      @input="form.codigo = form.codigo.toUpperCase()" />
      </v-col>
      <v-col cols="12" md="6">
        <v-label class="font-weight-bold mb-1">Placa</v-label>
        <v-text-field v-model="form.placa" placeholder="ej: GOW-1092" :rules="[rules.placa]"
                      @input="form.placa = form.placa?.toUpperCase()" />
      </v-col>

      <v-col cols="12" class="mt-2">
        <p class="text-subtitle-1 font-weight-bold text-primary mb-1">Características</p>
        <v-divider class="mb-3" />
      </v-col>
      <v-col cols="12" md="4">
        <v-label class="font-weight-bold mb-1">Marca</v-label>
        <v-text-field v-model="form.marca" placeholder="ej: Toyota" />
      </v-col>
      <v-col cols="12" md="4">
        <v-label class="font-weight-bold mb-1">Modelo</v-label>
        <v-text-field v-model="form.modelo" placeholder="ej: Hilux" />
      </v-col>
      <v-col cols="12" md="4">
        <v-label class="font-weight-bold mb-1">Año</v-label>
        <v-text-field v-model.number="form.anio" type="number" placeholder="ej: 2022" :rules="[rules.anio]" />
      </v-col>
      <v-col cols="12" md="4">
        <v-label class="font-weight-bold mb-1">Tipo de odómetro</v-label>
        <v-select v-model="form.tipoOdometro" :items="tiposOdometro" />
      </v-col>
      <v-col cols="12" md="4">
        <v-label class="font-weight-bold mb-1">Color</v-label>
        <v-text-field v-model="form.color" placeholder="ej: Blanco" />
      </v-col>
      <v-col cols="12" md="4">
        <v-label class="font-weight-bold mb-1">Capacidad de tanque (lts)</v-label>
        <v-text-field v-model.number="form.capacidadTanque" type="number" suffix="lts"
                      hint="Para calcular consumo en litros" persistent-hint />
      </v-col>
      <v-col cols="12" md="4">
        <v-label class="font-weight-bold mb-1">Estado administrativo</v-label>
        <v-select v-model="form.estadoAdmin" :items="estados"
                  hint="El estado en servicio/fuera se calcula con el switch" persistent-hint />
      </v-col>
      <v-col cols="12">
        <v-label class="font-weight-bold mb-1">Observaciones</v-label>
        <v-textarea v-model="form.observaciones" rows="2" placeholder="Notas adicionales..." />
      </v-col>

      <v-col cols="12" md="6">
        <v-btn variant="outlined" size="large" block color="secondary" :disabled="loading"
               @click="emit('cancelar')">Cancelar</v-btn>
      </v-col>
      <v-col cols="12" md="6">
        <v-btn type="submit" color="primary" size="large" block :loading="loading">Guardar</v-btn>
      </v-col>
    </v-row>
  </v-form>
</template>
