import 'vuetify/styles';
import '@mdi/font/css/materialdesignicons.css';
import { createVuetify } from 'vuetify';
import { aliases, mdi } from 'vuetify/iconsets/mdi';

// Paleta inspirada en el template Modernize (azul corporativo + acentos)
const hkLight = {
  dark: false,
  colors: {
    primary: '#5D87FF',
    secondary: '#49BEFF',
    success: '#13DEB9',
    info: '#539BFF',
    warning: '#FFAE1F',
    error: '#FA896B',
    background: '#F6F9FC',
    surface: '#FFFFFF',
    'on-surface': '#2A3547',
    muted: '#7C8FAC',
  },
};

export default createVuetify({
  icons: { defaultSet: 'mdi', aliases, sets: { mdi } },
  theme: {
    defaultTheme: 'hkLight',
    themes: { hkLight },
  },
  defaults: {
    VCard: { rounded: 'lg', elevation: 0, border: true },
    VBtn: { rounded: 'md', flat: true },
    VTextField: { variant: 'outlined', density: 'comfortable', hideDetails: 'auto', color: 'primary' },
    VSelect: { variant: 'outlined', density: 'comfortable', hideDetails: 'auto', color: 'primary' },
    VTextarea: { variant: 'outlined', color: 'primary', hideDetails: 'auto' },
  },
});
