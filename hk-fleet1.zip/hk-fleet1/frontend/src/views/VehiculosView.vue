<script setup lang="ts">
import { ref, onMounted } from 'vue';
import { useRouter } from 'vue-router';
import api from '@/services/api';
import { useAuthStore } from '@/stores/auth';
import VehiculoForm from '@/components/forms/VehiculoForm.vue';
import type { Vehiculo } from '@/types';

const router = useRouter();
const auth = useAuthStore();
const filas = ref<any[]>([]);
const cargando = ref(true);
const dialog = ref(false);
const editando = ref<Partial<Vehiculo> | null>(null);

const headers = [
  { title: 'Código', key: 'vehiculo.codigo' },
  { title: 'Placa', key: 'vehiculo.placa' },
  { title: 'Marca / Modelo', key: 'marcaModelo' },
  { title: 'Estado operativo', key: 'operativo' },
  { title: '', key: 'acciones', sortable: false, align: 'end' as const },
];
const estado: Record<string, { label: string; color: string }> = {
  EN_SERVICIO: { label: 'En servicio', color: 'success' },
  FUERA_SERVICIO: { label: 'Fuera de servicio', color: 'error' },
  BAJA: { label: 'De baja', color: 'medium-emphasis' },
  SIN_DATOS: { label: 'Sin datos', color: 'warning' },
};

async function cargar() {
  cargando.value = true;
  filas.value = (await api.get('/analytics/resumen')).data.vehiculos;
  cargando.value = false;
}
function nuevo() { editando.value = null; dialog.value = true; }
function editar(v: Vehiculo) { editando.value = { ...v }; dialog.value = true; }
function onGuardado() { dialog.value = false; cargar(); }

onMounted(cargar);
</script>

<template>
  <div>
    <div class="d-flex align-center mb-6">
      <div>
        <h1 class="text-h5 font-weight-bold">Vehículos</h1>
        <p class="text-body-2 text-medium-emphasis">
          {{ auth.puedeGestionarActivos ? 'Gestión de activos de la flota' : 'Verificación de equipos' }}
        </p>
      </div>
      <v-spacer />
      <v-btn v-if="auth.puedeGestionarActivos" color="primary" prepend-icon="mdi-plus" @click="nuevo">
        Nuevo vehículo
      </v-btn>
    </div>

    <v-card>
      <v-data-table :headers="headers" :items="filas" :loading="cargando" hover>
        <template #item.marcaModelo="{ item }">{{ item.vehiculo.marca }} {{ item.vehiculo.modelo }}</template>
        <template #item.operativo="{ item }">
          <v-chip :color="estado[item.operativo]?.color" size="small" variant="tonal">
            {{ estado[item.operativo]?.label }}
          </v-chip>
        </template>
        <template #item.acciones="{ item }">
          <v-btn icon="mdi-eye" size="small" variant="text" @click="router.push(`/vehiculos/${item.vehiculo.id}`)" />
          <v-btn v-if="auth.puedeGestionarActivos" icon="mdi-pencil" size="small" variant="text"
                 @click="editar(item.vehiculo)" />
        </template>
      </v-data-table>
    </v-card>

    <v-dialog v-model="dialog" max-width="800" scrollable>
      <v-card>
        <v-card-title class="font-weight-bold pa-5">{{ editando ? 'Editar' : 'Nuevo' }} vehículo</v-card-title>
        <v-divider />
        <v-card-text class="pa-5">
          <VehiculoForm :model-value="editando" @guardado="onGuardado" @cancelar="dialog = false" />
        </v-card-text>
      </v-card>
    </v-dialog>
  </div>
</template>
