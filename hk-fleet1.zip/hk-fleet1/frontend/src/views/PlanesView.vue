<script setup lang="ts">
import { ref, onMounted } from 'vue';
import api from '@/services/api';
import { useAuthStore } from '@/stores/auth';
import PlanMantenimientoForm from '@/components/forms/PlanMantenimientoForm.vue';

const auth = useAuthStore();
const items = ref<any[]>([]);
const cargando = ref(true);
const dialog = ref(false);

const headers = [
  { title: 'Vehículo', key: 'vehiculo.codigo' },
  { title: 'Plan', key: 'nombre' },
  { title: 'Categoría', key: 'categoria' },
  { title: 'Periodicidad', key: 'tipoPeriodicidad' },
  { title: 'Urgencia', key: 'nivelUrgencia' },
  { title: 'Activo', key: 'activo' },
  { title: '', key: 'acciones', sortable: false, align: 'end' as const },
];
const urgenciaColor: Record<string, string> = { BAJA: 'success', MEDIA: 'info', ALTA: 'warning', CRITICA: 'error' };
const periodLabel: Record<string, string> = {
  HOROMETRO: 'Horómetro', ODOMETRO: 'Odómetro', TIEMPO: 'Tiempo',
  ODOMETRO_TIEMPO: 'Odómetro + Tiempo', HOROMETRO_TIEMPO: 'Horómetro + Tiempo',
};

async function cargar() { cargando.value = true; items.value = (await api.get('/planes')).data; cargando.value = false; }
function onGuardado() { dialog.value = false; cargar(); }
async function eliminar(id: number) {
  if (!confirm('¿Eliminar este plan de mantenimiento?')) return;
  await api.delete(`/planes/${id}`); cargar();
}
async function ejecutar(id: number) {
  if (!confirm('¿Registrar ejecución? Esto reinicia el contador del próximo vencimiento.')) return;
  await api.post(`/planes/${id}/ejecutar`); cargar();
}
onMounted(cargar);
</script>

<template>
  <div>
    <div class="d-flex align-center mb-6">
      <div>
        <h1 class="text-h5 font-weight-bold">Planes de mantenimiento</h1>
        <p class="text-body-2 text-medium-emphasis">Mantenimientos recurrentes por horómetro, odómetro o tiempo</p>
      </div>
      <v-spacer />
      <v-btn v-if="auth.puedeGestionarPlanes" color="primary" prepend-icon="mdi-plus" @click="dialog = true">
        Nuevo plan
      </v-btn>
    </div>

    <v-card>
      <v-data-table :headers="headers" :items="items" :loading="cargando" hover>
        <template #item.tipoPeriodicidad="{ item }">{{ periodLabel[item.tipoPeriodicidad] }}</template>
        <template #item.nivelUrgencia="{ item }">
          <v-chip :color="urgenciaColor[item.nivelUrgencia]" size="small" variant="tonal">{{ item.nivelUrgencia }}</v-chip>
        </template>
        <template #item.activo="{ item }">
          <v-icon :color="item.activo ? 'success' : 'medium-emphasis'">
            {{ item.activo ? 'mdi-check-circle' : 'mdi-circle-outline' }}</v-icon>
        </template>
        <template #item.acciones="{ item }">
          <v-btn v-if="auth.puedeGestionarPlanes" icon="mdi-check-decagram" size="small" variant="text"
                 color="success" title="Registrar ejecución" @click="ejecutar(item.id)" />
          <v-btn v-if="auth.puedeGestionarPlanes" icon="mdi-delete" size="small" variant="text"
                 color="error" @click="eliminar(item.id)" />
        </template>
      </v-data-table>
    </v-card>

    <v-dialog v-model="dialog" max-width="1000" scrollable>
      <v-card>
        <v-card-title class="font-weight-bold pa-5">Nuevo plan de mantenimiento</v-card-title>
        <v-divider />
        <v-card-text class="pa-5">
          <PlanMantenimientoForm @guardado="onGuardado" @cancelar="dialog = false" />
        </v-card-text>
      </v-card>
    </v-dialog>
  </div>
</template>
