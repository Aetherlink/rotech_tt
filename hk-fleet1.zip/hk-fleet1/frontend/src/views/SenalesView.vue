<script setup lang="ts">
import { ref, reactive, onMounted } from 'vue';
import api from '@/services/api';
import type { Senal } from '@/types';

// Aquí gestionas el CATÁLOGO de señales. Agregar una fila = nueva tarjeta/gráfico
// en el dashboard, automáticamente. Es el "template engine" de tu monitoreo.
const senales = ref<Senal[]>([]);
const cargando = ref(true);
const dialog = ref(false);
const guardando = ref(false);
const error = ref('');

const tipos = ['NUMERICO', 'BOOLEANO', 'TEXTO', 'ENUM'];
const iconos = ['mdi-gauge', 'mdi-gas-station', 'mdi-engine', 'mdi-thermometer', 'mdi-speedometer',
  'mdi-oil', 'mdi-battery', 'mdi-power', 'mdi-water', 'mdi-fan', 'mdi-car-brake-alert', 'mdi-chart-line'];

const vacio = (): any => ({
  clave: '', etiqueta: '', unidad: '', tipo: 'NUMERICO', categoria: 'General',
  icono: 'mdi-chart-line', color: '#5D87FF', decimales: 1, minimo: null, maximo: null,
  umbralAlerta: null, agregable: true, activo: true, orden: 0,
});
const form = reactive<any>(vacio());

const headers = [
  { title: 'Clave', key: 'clave' }, { title: 'Etiqueta', key: 'etiqueta' },
  { title: 'Unidad', key: 'unidad' }, { title: 'Categoría', key: 'categoria' },
  { title: 'Tipo', key: 'tipo' }, { title: 'Activa', key: 'activo' },
  { title: '', key: 'acciones', sortable: false, align: 'end' as const },
];

async function cargar() {
  cargando.value = true;
  senales.value = (await api.get('/senales')).data;
  cargando.value = false;
}
function nueva() { Object.assign(form, vacio()); dialog.value = true; }
function editar(s: Senal) { Object.assign(form, s); dialog.value = true; }

async function guardar() {
  guardando.value = true; error.value = '';
  try {
    const { id, createdAt, ...data } = form;
    if (id) await api.put(`/senales/${id}`, data);
    else await api.post('/senales', data);
    dialog.value = false; cargar();
  } catch (e: any) {
    error.value = e.response?.data?.error || 'Error al guardar';
  } finally { guardando.value = false; }
}

async function eliminar(s: Senal) {
  if (!confirm(`¿Eliminar la señal "${s.etiqueta}"?`)) return;
  await api.delete(`/senales/${s.id}`); cargar();
}

onMounted(cargar);
</script>

<template>
  <div>
    <div class="d-flex align-center mb-2">
      <div>
        <h1 class="text-h5 font-weight-bold">Señales</h1>
        <p class="text-body-2 text-medium-emphasis">Define las métricas que llegan del ECU</p>
      </div>
      <v-spacer />
      <v-btn color="primary" prepend-icon="mdi-plus" @click="nueva">Nueva señal</v-btn>
    </div>
    <v-alert type="info" variant="tonal" density="compact" class="mb-4">
      Cada señal definida aquí se pinta automáticamente en el dashboard. Para una señal nueva del
      ECU, créala con la misma <strong>clave</strong> que envía tu dispositivo (ej: <code>rpm</code>).
    </v-alert>

    <v-card>
      <v-data-table :headers="headers" :items="senales" :loading="cargando" hover>
        <template #item.activo="{ item }">
          <v-icon :color="item.activo ? 'success' : 'medium-emphasis'">
            {{ item.activo ? 'mdi-check-circle' : 'mdi-circle-outline' }}
          </v-icon>
        </template>
        <template #item.acciones="{ item }">
          <v-btn icon="mdi-pencil" size="small" variant="text" @click="editar(item)" />
          <v-btn icon="mdi-delete" size="small" variant="text" color="error" @click="eliminar(item)" />
        </template>
      </v-data-table>
    </v-card>

    <v-dialog v-model="dialog" max-width="720" scrollable>
      <v-card>
        <v-card-title class="font-weight-bold pa-5">{{ form.id ? 'Editar' : 'Nueva' }} señal</v-card-title>
        <v-divider />
        <v-card-text class="pa-5">
          <v-alert v-if="error" type="error" variant="tonal" density="compact" class="mb-4">{{ error }}</v-alert>
          <v-row>
            <v-col cols="12" md="6">
              <v-label class="font-weight-bold mb-1">Clave (la que envía el ECU) <span class="text-error">*</span></v-label>
              <v-text-field v-model="form.clave" placeholder="ej: rpm" hint="minúsculas, números, _" />
            </v-col>
            <v-col cols="12" md="6">
              <v-label class="font-weight-bold mb-1">Etiqueta <span class="text-error">*</span></v-label>
              <v-text-field v-model="form.etiqueta" placeholder="ej: Revoluciones" />
            </v-col>
            <v-col cols="6" md="3">
              <v-label class="font-weight-bold mb-1">Unidad</v-label>
              <v-text-field v-model="form.unidad" placeholder="rpm" />
            </v-col>
            <v-col cols="6" md="3">
              <v-label class="font-weight-bold mb-1">Categoría</v-label>
              <v-text-field v-model="form.categoria" />
            </v-col>
            <v-col cols="6" md="3">
              <v-label class="font-weight-bold mb-1">Tipo</v-label>
              <v-select v-model="form.tipo" :items="tipos" />
            </v-col>
            <v-col cols="6" md="3">
              <v-label class="font-weight-bold mb-1">Decimales</v-label>
              <v-text-field v-model.number="form.decimales" type="number" />
            </v-col>
            <v-col cols="6" md="4">
              <v-label class="font-weight-bold mb-1">Ícono</v-label>
              <v-select v-model="form.icono" :items="iconos">
                <template #selection="{ item }"><v-icon class="mr-2">{{ item.value }}</v-icon>{{ item.value }}</template>
                <template #item="{ item, props: p }">
                  <v-list-item v-bind="p"><template #prepend><v-icon>{{ item.value }}</v-icon></template></v-list-item>
                </template>
              </v-select>
            </v-col>
            <v-col cols="6" md="4">
              <v-label class="font-weight-bold mb-1">Color</v-label>
              <v-text-field v-model="form.color" type="color" />
            </v-col>
            <v-col cols="6" md="4">
              <v-label class="font-weight-bold mb-1">Umbral de alerta</v-label>
              <v-text-field v-model.number="form.umbralAlerta" type="number" placeholder="opcional" />
            </v-col>
            <v-col cols="6" md="6">
              <v-switch v-model="form.agregable" color="primary" label="Graficable en el tiempo" inset />
            </v-col>
            <v-col cols="6" md="6">
              <v-switch v-model="form.activo" color="primary" label="Activa (visible)" inset />
            </v-col>
          </v-row>
        </v-card-text>
        <v-divider />
        <v-card-actions class="pa-4">
          <v-spacer />
          <v-btn variant="text" @click="dialog = false">Cancelar</v-btn>
          <v-btn color="primary" :loading="guardando" @click="guardar">Guardar</v-btn>
        </v-card-actions>
      </v-card>
    </v-dialog>
  </div>
</template>
