<script setup lang="ts">
import { ref, onMounted, computed } from 'vue';
import { useRoute } from 'vue-router';
import api from '@/services/api';
import SignalCard from '@/components/SignalCard.vue';
import TrendChart from '@/components/TrendChart.vue';
import EquipoUsoChart from '@/components/EquipoUsoChart.vue';
import type { Senal, Vehiculo } from '@/types';

const route = useRoute();
const vehiculo = ref<Vehiculo | null>(null);
const senales = ref<Senal[]>([]);
const ultimo = ref<Record<string, any> | null>(null);
const cargando = ref(true);

const graficables = computed(() => senales.value.filter((s) => s.agregable && s.tipo === 'NUMERICO'));

async function cargar() {
  cargando.value = true;
  const v = (await api.get(`/vehiculos/${route.params.id}`)).data;
  vehiculo.value = v;
  senales.value = (await api.get('/senales', { params: { activo: true } })).data;
  try { ultimo.value = (await api.get(`/telemetria/${v.codigo}/ultimo`)).data; }
  catch { ultimo.value = null; }
  cargando.value = false;
}
onMounted(cargar);
</script>

<template>
  <div v-if="vehiculo">
    <div class="d-flex align-center mb-6">
      <v-btn icon="mdi-arrow-left" variant="text" class="mr-2" @click="$router.back()" />
      <div>
        <h1 class="text-h5 font-weight-bold">{{ vehiculo.codigo }}
          <span class="text-medium-emphasis text-h6">· {{ vehiculo.placa }}</span></h1>
        <p class="text-body-2 text-medium-emphasis">{{ vehiculo.marca }} {{ vehiculo.modelo }} · {{ vehiculo.anio }}</p>
      </div>
      <v-spacer />
      <v-btn variant="text" prepend-icon="mdi-refresh" @click="cargar">Actualizar</v-btn>
    </div>

    <v-progress-linear v-if="cargando" indeterminate color="primary" class="mb-4" />

    <template v-else>
      <h2 class="text-subtitle-1 font-weight-bold mb-3">Lecturas actuales</h2>
      <v-row v-if="ultimo" class="mb-4">
        <v-col v-for="s in senales" :key="s.id" cols="12" sm="6" md="4" lg="3">
          <SignalCard :senal="s" :valor="ultimo[s.clave] ?? null" />
        </v-col>
      </v-row>
      <v-alert v-else type="info" variant="tonal" class="mb-4">Sin telemetría aún.</v-alert>

      <!-- Uso de equipo y motor encendido (semanal por defecto, con rango de fechas) -->
      <v-row class="mb-2">
        <v-col cols="12">
          <EquipoUsoChart :codigo="vehiculo.codigo" modo="uso" titulo="Uso de equipo" />
        </v-col>
        <v-col cols="12">
          <EquipoUsoChart :codigo="vehiculo.codigo" modo="motor" titulo="Motor encendido" />
        </v-col>
      </v-row>

      <h2 class="text-subtitle-1 font-weight-bold mb-3 mt-2">Tendencias de señales</h2>
      <v-row>
        <v-col v-for="s in graficables" :key="s.id" cols="12" md="6">
          <TrendChart :codigo="vehiculo.codigo" :senal="s" />
        </v-col>
      </v-row>
    </template>
  </div>
</template>
