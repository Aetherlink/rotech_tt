<script setup lang="ts">
import { ref, onMounted } from 'vue';
import api from '@/services/api';
import AreaTrendCard from '@/components/AreaTrendCard.vue';
import ProximosMantenimientos from '@/components/ProximosMantenimientos.vue';
import DateRangePicker from '@/components/DateRangePicker.vue';
import type { ProximoMantenimiento } from '@/types';

const totales = ref({ total: 0, enServicio: 0, fueraServicio: 0, baja: 0 });
const km = ref<{ serie: any[]; total: number; variacion: number | null }>({ serie: [], total: 0, variacion: null });
const fuel = ref<{ serie: any[]; total: number; unidad: string; variacion: number | null }>({ serie: [], total: 0, unidad: 'lts', variacion: null });
const proximos = ref<ProximoMantenimiento[]>([]);
const cargandoProx = ref(true);
let rango = { desde: '', hasta: '' };

// Pide el periodo actual y el inmediatamente anterior (igual longitud) para la variación %.
function periodoAnterior(r: { desde: string; hasta: string }) {
  const d = new Date(r.desde), h = new Date(r.hasta);
  const ms = h.getTime() - d.getTime();
  return { desde: new Date(d.getTime() - ms - 864e5).toISOString().slice(0, 10),
           hasta: new Date(d.getTime() - 864e5).toISOString().slice(0, 10) };
}
const pct = (act: number, ant: number) => (ant > 0 ? Math.round(((act - ant) / ant) * 1000) / 10 : null);

async function cargarRango(r: { desde: string; hasta: string }) {
  rango = r;
  const ant = periodoAnterior(r);
  const [kmAct, kmAnt, fAct, fAnt] = await Promise.all([
    api.get('/analytics/km-recorridos', { params: r }),
    api.get('/analytics/km-recorridos', { params: ant }),
    api.get('/analytics/combustible', { params: r }),
    api.get('/analytics/combustible', { params: ant }),
  ]);
  km.value = { serie: kmAct.data.serie, total: kmAct.data.total, variacion: pct(kmAct.data.total, kmAnt.data.total) };
  fuel.value = { serie: fAct.data.serie, total: fAct.data.total, unidad: fAct.data.unidad, variacion: pct(fAct.data.total, fAnt.data.total) };
}

async function cargarFijos() {
  totales.value = (await api.get('/analytics/resumen')).data.totales;
  proximos.value = (await api.get('/analytics/proximos-mantenimientos')).data;
  cargandoProx.value = false;
}

onMounted(cargarFijos);
</script>

<template>
  <div>
    <div class="d-flex align-center justify-space-between flex-wrap ga-2 mb-6">
      <div>
        <h1 class="text-h5 font-weight-bold">Dashboard</h1>
        <p class="text-body-2 text-medium-emphasis">Resumen de la flota</p>
      </div>
      <DateRangePicker @cambio="cargarRango" />
    </div>

    <!-- KPIs: estado operativo derivado de la señal switch -->
    <v-row class="mb-2">
      <v-col cols="12" sm="3">
        <v-card><v-card-text class="d-flex align-center ga-4">
          <v-avatar color="#5D87FF1A" rounded="lg" size="52"><v-icon color="primary">mdi-truck</v-icon></v-avatar>
          <div><p class="text-medium-emphasis text-body-2">Vehículos</p>
          <span class="text-h5 font-weight-bold">{{ totales.total }}</span></div>
        </v-card-text></v-card>
      </v-col>
      <v-col cols="12" sm="3">
        <v-card><v-card-text class="d-flex align-center ga-4">
          <v-avatar color="#13DEB91A" rounded="lg" size="52"><v-icon color="success">mdi-check-circle</v-icon></v-avatar>
          <div><p class="text-medium-emphasis text-body-2">En servicio</p>
          <span class="text-h5 font-weight-bold">{{ totales.enServicio }}</span></div>
        </v-card-text></v-card>
      </v-col>
      <v-col cols="12" sm="3">
        <v-card><v-card-text class="d-flex align-center ga-4">
          <v-avatar color="#FA896B1A" rounded="lg" size="52"><v-icon color="error">mdi-alert-octagon</v-icon></v-avatar>
          <div><p class="text-medium-emphasis text-body-2">Fuera de servicio</p>
          <span class="text-h5 font-weight-bold">{{ totales.fueraServicio }}</span></div>
        </v-card-text></v-card>
      </v-col>
      <v-col cols="12" sm="3">
        <v-card><v-card-text class="d-flex align-center ga-4">
          <v-avatar color="#7C8FAC1A" rounded="lg" size="52"><v-icon color="medium-emphasis">mdi-cancel</v-icon></v-avatar>
          <div><p class="text-medium-emphasis text-body-2">De baja</p>
          <span class="text-h5 font-weight-bold">{{ totales.baja }}</span></div>
        </v-card-text></v-card>
      </v-col>
    </v-row>

    <!-- Charts de flota -->
    <v-row class="mb-2">
      <v-col cols="12" md="6">
        <AreaTrendCard titulo="Kilómetros recorridos" :total="km.total" unidad="km"
                       :variacion="km.variacion" :serie="km.serie" color="#5D87FF" />
      </v-col>
      <v-col cols="12" md="6">
        <AreaTrendCard titulo="Combustible consumido" :total="fuel.total" :unidad="fuel.unidad"
                       :variacion="fuel.variacion" :serie="fuel.serie" color="#FA896B" />
      </v-col>
    </v-row>

    <!-- Próximos mantenimientos -->
    <v-row>
      <v-col cols="12">
        <ProximosMantenimientos :items="proximos" :cargando="cargandoProx" />
      </v-col>
    </v-row>
  </div>
</template>
