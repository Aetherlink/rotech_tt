<script setup lang="ts">
import { ref, reactive, onMounted } from 'vue';
import api from '@/services/api';
import { useAuthStore } from '@/stores/auth';
import type { Usuario } from '@/types';

const auth = useAuthStore();
const usuarios = ref<Usuario[]>([]);
const cargando = ref(true);
const dialog = ref(false);
const editando = ref<Usuario | null>(null);
const error = ref('');
const guardando = ref(false);
const formRef = ref<any>(null);

const roles = [
  { title: 'Administrador — gestiona todo', value: 'ADMIN' },
  { title: 'Supervisor — edita planes, no crea activos', value: 'SUPERVISOR' },
  { title: 'Operador — solo verificación (lectura)', value: 'OPERADOR' },
];
const rolColor: Record<string, string> = { ADMIN: 'primary', SUPERVISOR: 'info', OPERADOR: 'secondary' };

const form = reactive<any>({ email: '', nombre: '', password: '', rol: 'OPERADOR', activo: true });
const rules = {
  required: (v: any) => !!v || 'Requerido',
  email: (v: string) => /.+@.+\..+/.test(v) || 'Email inválido',
  pass: (v: string) => (editando.value ? true : (v?.length >= 6 || 'Mínimo 6 caracteres')),
};

const headers = [
  { title: 'Nombre', key: 'nombre' },
  { title: 'Email', key: 'email' },
  { title: 'Rol', key: 'rol' },
  { title: 'Estado', key: 'activo' },
  { title: '', key: 'acciones', sortable: false, align: 'end' as const },
];

async function cargar() { cargando.value = true; usuarios.value = (await api.get('/usuarios')).data; cargando.value = false; }

function nuevo() {
  editando.value = null;
  Object.assign(form, { email: '', nombre: '', password: '', rol: 'OPERADOR', activo: true });
  error.value = ''; dialog.value = true;
}
function editar(u: Usuario) {
  editando.value = u;
  Object.assign(form, { email: u.email, nombre: u.nombre, password: '', rol: u.rol, activo: u.activo });
  error.value = ''; dialog.value = true;
}

async function guardar() {
  const { valid } = await formRef.value.validate();
  if (!valid) return;
  guardando.value = true; error.value = '';
  try {
    if (editando.value) {
      const payload: any = { nombre: form.nombre, rol: form.rol, activo: form.activo };
      if (form.password) payload.password = form.password;
      await api.put(`/usuarios/${editando.value.id}`, payload);
    } else {
      await api.post('/usuarios', form);
    }
    dialog.value = false; cargar();
  } catch (e: any) {
    error.value = e.response?.data?.error || 'Error al guardar el usuario';
  } finally { guardando.value = false; }
}

async function eliminar(u: Usuario) {
  if (u.id === auth.usuario?.id) return;
  if (!confirm(`¿Eliminar al usuario ${u.nombre}?`)) return;
  await api.delete(`/usuarios/${u.id}`); cargar();
}

onMounted(cargar);
</script>

<template>
  <div>
    <div class="d-flex align-center mb-6">
      <div>
        <h1 class="text-h5 font-weight-bold">Usuarios</h1>
        <p class="text-body-2 text-medium-emphasis">Creación de usuarios y asignación de roles</p>
      </div>
      <v-spacer />
      <v-btn color="primary" prepend-icon="mdi-account-plus" @click="nuevo">Nuevo usuario</v-btn>
    </div>

    <v-card>
      <v-data-table :headers="headers" :items="usuarios" :loading="cargando" hover>
        <template #item.rol="{ item }">
          <v-chip :color="rolColor[item.rol]" size="small" variant="tonal">{{ item.rol }}</v-chip>
        </template>
        <template #item.activo="{ item }">
          <v-chip :color="item.activo ? 'success' : 'medium-emphasis'" size="small" variant="tonal">
            {{ item.activo ? 'Activo' : 'Inactivo' }}
          </v-chip>
        </template>
        <template #item.acciones="{ item }">
          <v-btn icon="mdi-pencil" size="small" variant="text" @click="editar(item)" />
          <v-btn icon="mdi-delete" size="small" variant="text" color="error"
                 :disabled="item.id === auth.usuario?.id" @click="eliminar(item)" />
        </template>
      </v-data-table>
    </v-card>

    <v-dialog v-model="dialog" max-width="540">
      <v-card>
        <v-card-title class="font-weight-bold pa-5">{{ editando ? 'Editar' : 'Nuevo' }} usuario</v-card-title>
        <v-divider />
        <v-card-text class="pa-5">
          <v-alert v-if="error" type="error" variant="tonal" density="compact" class="mb-4">{{ error }}</v-alert>
          <v-form ref="formRef" @submit.prevent="guardar">
            <v-label class="font-weight-bold mb-1">Nombre <span class="text-error">*</span></v-label>
            <v-text-field v-model="form.nombre" class="mb-2" :rules="[rules.required]" />

            <v-label class="font-weight-bold mb-1">Email <span class="text-error">*</span></v-label>
            <v-text-field v-model="form.email" type="email" class="mb-2"
                          :disabled="!!editando" :rules="[rules.required, rules.email]" />

            <v-label class="font-weight-bold mb-1">
              Contraseña <span v-if="!editando" class="text-error">*</span>
              <span v-else class="text-caption text-medium-emphasis">(dejar vacío para no cambiar)</span>
            </v-label>
            <v-text-field v-model="form.password" type="password" class="mb-2" :rules="[rules.pass]" />

            <v-label class="font-weight-bold mb-1">Rol <span class="text-error">*</span></v-label>
            <v-select v-model="form.rol" :items="roles" item-title="title" item-value="value"
                      class="mb-2" :rules="[rules.required]" />

            <v-switch v-model="form.activo" label="Usuario activo" color="success" inset hide-details />

            <div class="d-flex ga-3 mt-4">
              <v-btn variant="outlined" color="secondary" block @click="dialog = false">Cancelar</v-btn>
              <v-btn type="submit" color="primary" block :loading="guardando">Guardar</v-btn>
            </div>
          </v-form>
        </v-card-text>
      </v-card>
    </v-dialog>
  </div>
</template>
