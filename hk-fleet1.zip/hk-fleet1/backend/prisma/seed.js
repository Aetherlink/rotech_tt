// Seed v2: usuarios (3 roles), señales, 4 vehículos, planes de mantenimiento
// y telemetría histórica de 14 días para que los charts tengan datos.
const { PrismaClient } = require('@prisma/client');
const bcrypt = require('bcryptjs');
const prisma = new PrismaClient();

const senales = [
  { clave: 'odometro_km', etiqueta: 'Odómetro', unidad: 'km', categoria: 'Recorrido', icono: 'mdi-gauge', color: '#5D87FF', decimales: 2, orden: 1 },
  { clave: 'nivel_combustible', etiqueta: 'Nivel de combustible', unidad: '%', categoria: 'Combustible', icono: 'mdi-gas-station', color: '#13DEB9', decimales: 1, minimo: 0, maximo: 100, orden: 2 },
  { clave: 'horas_motor', etiqueta: 'Horas de motor', unidad: 'h', categoria: 'Motor', icono: 'mdi-engine', color: '#539BFF', decimales: 1, orden: 3 },
  { clave: 'horas_ralenti', etiqueta: 'Horas en ralentí', unidad: 'h', categoria: 'Motor', icono: 'mdi-engine-outline', color: '#FFAE1F', decimales: 1, orden: 4 },
  { clave: 'temperatura_refrigerante', etiqueta: 'Temp. refrigerante', unidad: '°C', categoria: 'Motor', icono: 'mdi-thermometer', color: '#FA896B', decimales: 0, minimo: 0, maximo: 120, umbralAlerta: 100, orden: 5 },
  { clave: 'switch', etiqueta: 'Fuera de servicio', tipo: 'BOOLEANO', categoria: 'Estado', icono: 'mdi-power', color: '#49BEFF', agregable: false, orden: 6 },
];

const vehiculosSeed = [
  { codigo: 'HK0026', placa: 'GOW-1092', marca: 'Toyota', modelo: 'Hilux', anio: 2022, tipoOdometro: 'Kilometros', capacidadTanque: 80, finFueraServicio: false },
  { codigo: 'HK0031', placa: 'GTC-2540', marca: 'Hino', modelo: '300', anio: 2021, tipoOdometro: 'Kilometros', capacidadTanque: 100, finFueraServicio: true },
  { codigo: 'HK0042', placa: 'POV-8769', marca: 'Isuzu', modelo: 'NPR', anio: 2020, tipoOdometro: 'Kilometros', capacidadTanque: 90, finFueraServicio: false },
  { codigo: 'HK0055', placa: 'TA-4227', marca: 'Mercedes', modelo: 'Atego', anio: 2023, tipoOdometro: 'Kilometros', capacidadTanque: 120, finFueraServicio: false },
];

const planesSeed = [
  { codigo: 'HK0026', nombre: 'Cambio de filtro', categoria: 'Filtros', nivelUrgencia: 'BAJA', tipoPeriodicidad: 'ODOMETRO', intervaloOdometro: 8000, alertaOdometro: 500 },
  { codigo: 'HK0031', nombre: 'Reemplazo de baterías', categoria: 'Bateria', nivelUrgencia: 'MEDIA', tipoPeriodicidad: 'TIEMPO', intervaloDias: 2, unidadTiempo: 'Meses', alertaDias: 7 },
  { codigo: 'HK0042', nombre: 'Cambio de aceite', categoria: 'Lubricacion', nivelUrgencia: 'CRITICA', tipoPeriodicidad: 'ODOMETRO', intervaloOdometro: 5000, alertaOdometro: 300 },
  { codigo: 'HK0055', nombre: 'Cambio de neumáticos', categoria: 'Llantas y neumaticos', nivelUrgencia: 'ALTA', tipoPeriodicidad: 'ODOMETRO', intervaloOdometro: 40000, alertaOdometro: 2000 },
];

function generarTelemetria(codigo, finFueraServicio) {
  const filas = [];
  const ahora = Date.now();
  const inicio = ahora - 14 * 864e5;
  let odo = 130000 + Math.random() * 10000;
  let horasMotor = 24000 + Math.random() * 2000;
  let horasRalenti = horasMotor * 0.4;
  let combustible = 90;
  const tanque = 90;

  for (let t = inicio; t <= ahora; t += 2 * 3600 * 1000) {
    const fecha = new Date(t);
    const hora = fecha.getHours();
    const enJornada = hora >= 7 && hora <= 18;
    const activo = enJornada && Math.random() > 0.25; // 75% de bloques diurnos trabaja

    if (activo) {
      const horasBloque = 2;
      const factorMotor = 0.6 + Math.random() * 0.4; // % del bloque con motor on
      const horasOn = horasBloque * factorMotor;
      const factorRalenti = 0.2 + Math.random() * 0.3;
      horasMotor += horasOn;
      horasRalenti += horasOn * factorRalenti;
      const horasMovimiento = horasOn * (1 - factorRalenti);
      odo += horasMovimiento * (35 + Math.random() * 25); // km/h promedio
      const consumoPct = horasOn * (3 + Math.random() * 2); // ~%/h
      combustible -= consumoPct;
      if (combustible < 20) combustible = 95; // recarga
    }
    // switch (fuera de servicio): casi siempre false; algunos picos true
    let sw = Math.random() < 0.05;
    if (t + 2 * 3600 * 1000 > ahora) sw = finFueraServicio; // último estado controlado

    filas.push({
      vehiculoCodigo: codigo,
      odometroKm: Math.round(odo * 100) / 100,
      nivelCombustible: Math.round(Math.max(combustible, 0) * 10) / 10,
      horasMotor: Math.round(horasMotor * 10) / 10,
      horasRalenti: Math.round(horasRalenti * 10) / 10,
      temperaturaRefrigerante: activo ? 78 + Math.round(Math.random() * 18) : 25 + Math.round(Math.random() * 10),
      switch: sw,
      createdAt: fecha,
    });
  }
  return filas;
}

async function main() {
  // Usuarios
  const usuarios = [
    { email: 'admin@hkfleet.com', nombre: 'Administrador', rol: 'ADMIN', password: 'admin123' },
    { email: 'supervisor@hkfleet.com', nombre: 'Supervisor Demo', rol: 'SUPERVISOR', password: 'demo123' },
    { email: 'operador@hkfleet.com', nombre: 'Operador Demo', rol: 'OPERADOR', password: 'demo123' },
  ];
  for (const u of usuarios) {
    await prisma.usuario.upsert({
      where: { email: u.email }, update: {},
      create: { ...u, password: await bcrypt.hash(u.password, 10) },
    });
  }

  for (const s of senales) await prisma.senal.upsert({ where: { clave: s.clave }, update: s, create: s });

  for (const v of vehiculosSeed) {
    const { finFueraServicio, ...data } = v;
    await prisma.vehiculo.upsert({ where: { codigo: v.codigo }, update: data, create: data });
  }

  // Telemetría histórica (borra la previa de estos códigos para no duplicar)
  console.log('Generando telemetría histórica...');
  for (const v of vehiculosSeed) {
    await prisma.telemetria.deleteMany({ where: { vehiculoCodigo: v.codigo } });
    const filas = generarTelemetria(v.codigo, v.finFueraServicio);
    await prisma.telemetria.createMany({ data: filas });
  }

  // Planes de mantenimiento (con línea base = última lectura)
  for (const p of planesSeed) {
    const veh = await prisma.vehiculo.findUnique({ where: { codigo: p.codigo } });
    const ult = await prisma.telemetria.findFirst({ where: { vehiculoCodigo: p.codigo }, orderBy: { createdAt: 'desc' } });
    const { codigo, ...rest } = p;
    await prisma.planMantenimiento.create({
      data: {
        ...rest, vehiculoId: veh.id, descripcion: `Plan ${p.nombre.toLowerCase()}`,
        baseFecha: new Date(Date.now() - 60 * 864e5), // se "creó" hace 60 días
        baseOdometro: ult ? ult.odometroKm - (p.intervaloOdometro ? p.intervaloOdometro * 0.85 : 0) : null,
        baseHorometro: ult?.horasMotor ?? null,
      },
    });
  }

  console.log('Seed v2 completado.');
  console.log('  ADMIN:      admin@hkfleet.com / admin123');
  console.log('  SUPERVISOR: supervisor@hkfleet.com / demo123');
  console.log('  OPERADOR:   operador@hkfleet.com / demo123');
}

main().catch((e) => { console.error(e); process.exit(1); }).finally(() => prisma.$disconnect());
