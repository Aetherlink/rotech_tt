-- CreateEnum
CREATE TYPE "Rol" AS ENUM ('ADMIN', 'SUPERVISOR', 'OPERADOR');

-- CreateEnum
CREATE TYPE "EstadoAdmin" AS ENUM ('OPERATIVO', 'BAJA');

-- CreateEnum
CREATE TYPE "TipoSenal" AS ENUM ('NUMERICO', 'BOOLEANO', 'TEXTO', 'ENUM');

-- CreateEnum
CREATE TYPE "TipoPeriodicidad" AS ENUM ('HOROMETRO', 'ODOMETRO', 'TIEMPO', 'ODOMETRO_TIEMPO', 'HOROMETRO_TIEMPO');

-- CreateEnum
CREATE TYPE "NivelUrgencia" AS ENUM ('BAJA', 'MEDIA', 'ALTA', 'CRITICA');

-- CreateTable
CREATE TABLE "usuarios" (
    "id" SERIAL NOT NULL,
    "email" TEXT NOT NULL,
    "nombre" TEXT NOT NULL,
    "password" TEXT NOT NULL,
    "rol" "Rol" NOT NULL DEFAULT 'OPERADOR',
    "activo" BOOLEAN NOT NULL DEFAULT true,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "usuarios_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "vehiculos" (
    "id" SERIAL NOT NULL,
    "codigo" TEXT NOT NULL,
    "placa" TEXT,
    "marca" TEXT,
    "modelo" TEXT,
    "anio" INTEGER,
    "color" TEXT,
    "tipo_odometro" TEXT,
    "capacidad_tanque" DOUBLE PRECISION,
    "estado_admin" "EstadoAdmin" NOT NULL DEFAULT 'OPERATIVO',
    "observaciones" TEXT,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "vehiculos_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "senales" (
    "id" SERIAL NOT NULL,
    "clave" TEXT NOT NULL,
    "etiqueta" TEXT NOT NULL,
    "unidad" TEXT,
    "tipo" "TipoSenal" NOT NULL DEFAULT 'NUMERICO',
    "categoria" TEXT NOT NULL DEFAULT 'General',
    "icono" TEXT,
    "color" TEXT,
    "decimales" INTEGER NOT NULL DEFAULT 1,
    "minimo" DOUBLE PRECISION,
    "maximo" DOUBLE PRECISION,
    "umbral_alerta" DOUBLE PRECISION,
    "agregable" BOOLEAN NOT NULL DEFAULT true,
    "activo" BOOLEAN NOT NULL DEFAULT true,
    "orden" INTEGER NOT NULL DEFAULT 0,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "senales_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "telemetria" (
    "id" BIGSERIAL NOT NULL,
    "vehiculo_id" TEXT NOT NULL,
    "odometro_km" DOUBLE PRECISION,
    "nivel_combustible" DOUBLE PRECISION,
    "horas_ralenti" DOUBLE PRECISION,
    "horas_motor" DOUBLE PRECISION,
    "temperatura_refrigerante" DOUBLE PRECISION,
    "switch" BOOLEAN DEFAULT false,
    "metrics" JSONB,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "telemetria_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "planes_mantenimiento" (
    "id" SERIAL NOT NULL,
    "vehiculo_id" INTEGER NOT NULL,
    "nombre" TEXT NOT NULL,
    "categoria" TEXT NOT NULL,
    "descripcion" TEXT,
    "requiere_detener_equipo" BOOLEAN NOT NULL DEFAULT true,
    "requiere_especialista" BOOLEAN NOT NULL DEFAULT false,
    "tipo_periodicidad" "TipoPeriodicidad" NOT NULL,
    "intervalo_horometro" DOUBLE PRECISION,
    "intervalo_odometro" DOUBLE PRECISION,
    "intervalo_dias" INTEGER,
    "unidad_tiempo" TEXT,
    "alerta_horometro" DOUBLE PRECISION,
    "alerta_odometro" DOUBLE PRECISION,
    "alerta_dias" INTEGER,
    "nivel_urgencia" "NivelUrgencia" NOT NULL DEFAULT 'MEDIA',
    "tiempo_estimado" DOUBLE PRECISION,
    "unidad_tiempo_estimado" TEXT,
    "personal_requerido" INTEGER,
    "perfil_personal" TEXT,
    "materiales" JSONB,
    "pasos" TEXT,
    "observaciones" TEXT,
    "activo" BOOLEAN NOT NULL DEFAULT true,
    "base_fecha" TIMESTAMP(3),
    "base_odometro" DOUBLE PRECISION,
    "base_horometro" DOUBLE PRECISION,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "planes_mantenimiento_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "usuarios_email_key" ON "usuarios"("email");

-- CreateIndex
CREATE UNIQUE INDEX "vehiculos_codigo_key" ON "vehiculos"("codigo");

-- CreateIndex
CREATE UNIQUE INDEX "senales_clave_key" ON "senales"("clave");

-- CreateIndex
CREATE INDEX "telemetria_vehiculo_id_created_at_idx" ON "telemetria"("vehiculo_id", "created_at");

-- AddForeignKey
ALTER TABLE "telemetria" ADD CONSTRAINT "telemetria_vehiculo_id_fkey" FOREIGN KEY ("vehiculo_id") REFERENCES "vehiculos"("codigo") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "planes_mantenimiento" ADD CONSTRAINT "planes_mantenimiento_vehiculo_id_fkey" FOREIGN KEY ("vehiculo_id") REFERENCES "vehiculos"("id") ON DELETE CASCADE ON UPDATE CASCADE;
