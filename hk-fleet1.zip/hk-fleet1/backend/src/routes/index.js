const router = require('express').Router();
router.use('/auth', require('./auth.routes'));
router.use('/usuarios', require('./usuario.routes'));
router.use('/vehiculos', require('./vehiculo.routes'));
router.use('/planes', require('./plan.routes'));
router.use('/senales', require('./senal.routes'));
router.use('/telemetria', require('./telemetria.routes'));
router.use('/analytics', require('./analytics.routes'));
module.exports = router;
