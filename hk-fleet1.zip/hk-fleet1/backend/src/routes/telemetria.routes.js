const router = require('express').Router();
const c = require('../controllers/telemetria.controller');
const { auth } = require('../middleware/auth');
router.get('/:codigo/ultimo', auth, c.ultimo);
router.get('/:codigo/serie', auth, c.serie);
router.post('/ingest', c.ingestar); // Node-RED (protégelo por red/API key si lo expones)
module.exports = router;
