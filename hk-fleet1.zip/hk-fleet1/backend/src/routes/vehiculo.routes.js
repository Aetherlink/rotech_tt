const router = require('express').Router();
const c = require('../controllers/vehiculo.controller');
const { auth, requireRol } = require('../middleware/auth');
router.use(auth);
router.get('/', c.listar);            // verificación: cualquier rol
router.get('/:id', c.obtener);
router.post('/', requireRol('ADMIN'), c.crear);        // solo ADMIN
router.put('/:id', requireRol('ADMIN'), c.actualizar); // solo ADMIN
router.delete('/:id', requireRol('ADMIN'), c.eliminar);
module.exports = router;
