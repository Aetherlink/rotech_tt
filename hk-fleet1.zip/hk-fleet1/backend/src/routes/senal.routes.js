const router = require('express').Router();
const c = require('../controllers/senal.controller');
const { auth, requireRol } = require('../middleware/auth');
router.use(auth);
router.get('/', c.listar);
router.post('/', requireRol('ADMIN'), c.crear);
router.put('/:id', requireRol('ADMIN'), c.actualizar);
router.delete('/:id', requireRol('ADMIN'), c.eliminar);
module.exports = router;
