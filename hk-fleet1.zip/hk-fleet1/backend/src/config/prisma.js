const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();
// Express no serializa BigInt (id de telemetria). Lo convertimos a string.
BigInt.prototype.toJSON = function () { return this.toString(); };
module.exports = prisma;
