const { z } = require('zod');
const prisma = require('../config/prisma');
const { asyncHandler } = require('../middleware/error');

const schema = z.object({
  clave: z.string().regex(/^[a-z0-9_]+$/, 'Usa minúsculas, números y guion bajo'),
  etiqueta: z.string().min(1),
  unidad: z.string().optional().nullable(),
  tipo: z.enum(['NUMERICO', 'BOOLEANO', 'TEXTO', 'ENUM']).optional(),
  categoria: z.string().optional(),
  icono: z.string().optional().nullable(),
  color: z.string().optional().nullable(),
  decimales: z.number().int().optional(),
  minimo: z.number().optional().nullable(),
  maximo: z.number().optional().nullable(),
  umbralAlerta: z.number().optional().nullable(),
  agregable: z.boolean().optional(),
  activo: z.boolean().optional(),
  orden: z.number().int().optional(),
});

exports.listar = asyncHandler(async (req, res) => {
  const where = req.query.activo === 'true' ? { activo: true } : {};
  const senales = await prisma.senal.findMany({ where, orderBy: [{ orden: 'asc' }, { etiqueta: 'asc' }] });
  res.json(senales);
});

exports.crear = asyncHandler(async (req, res) => {
  const senal = await prisma.senal.create({ data: schema.parse(req.body) });
  res.status(201).json(senal);
});

exports.actualizar = asyncHandler(async (req, res) => {
  const senal = await prisma.senal.update({ where: { id: Number(req.params.id) }, data: schema.partial().parse(req.body) });
  res.json(senal);
});

exports.eliminar = asyncHandler(async (req, res) => {
  await prisma.senal.delete({ where: { id: Number(req.params.id) } });
  res.status(204).end();
});
