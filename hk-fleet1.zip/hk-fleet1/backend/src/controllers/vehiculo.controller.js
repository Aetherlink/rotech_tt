const { z } = require('zod');
const prisma = require('../config/prisma');
const { asyncHandler } = require('../middleware/error');

// Sin VIN, número de motor ni asignación (área/conductor).
const schema = z.object({
  codigo: z.string().min(1),
  placa: z.string().optional().nullable(),
  marca: z.string().optional().nullable(),
  modelo: z.string().optional().nullable(),
  anio: z.number().int().optional().nullable(),
  color: z.string().optional().nullable(),
  tipoOdometro: z.string().optional().nullable(),
  capacidadTanque: z.number().optional().nullable(),
  estadoAdmin: z.enum(['OPERATIVO', 'BAJA']).optional(),
  observaciones: z.string().optional().nullable(),
});

exports.listar = asyncHandler(async (req, res) => {
  res.json(await prisma.vehiculo.findMany({ orderBy: { codigo: 'asc' } }));
});

exports.obtener = asyncHandler(async (req, res) => {
  const vehiculo = await prisma.vehiculo.findUnique({
    where: { id: Number(req.params.id) },
    include: { planes: { orderBy: { createdAt: 'desc' } } },
  });
  if (!vehiculo) return res.status(404).json({ error: 'Vehículo no encontrado' });
  res.json(vehiculo);
});

exports.crear = asyncHandler(async (req, res) => {
  const vehiculo = await prisma.vehiculo.create({ data: schema.parse(req.body) });
  res.status(201).json(vehiculo);
});

exports.actualizar = asyncHandler(async (req, res) => {
  const vehiculo = await prisma.vehiculo.update({
    where: { id: Number(req.params.id) }, data: schema.partial().parse(req.body),
  });
  res.json(vehiculo);
});

exports.eliminar = asyncHandler(async (req, res) => {
  await prisma.vehiculo.delete({ where: { id: Number(req.params.id) } });
  res.status(204).end();
});
