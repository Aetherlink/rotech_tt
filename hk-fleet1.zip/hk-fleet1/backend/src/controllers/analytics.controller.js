const prisma = require('../config/prisma');
const { asyncHandler } = require('../middleware/error');

// Rango por defecto: últimos 7 días (semanal)
function rango(req) {
  const hasta = req.query.hasta ? new Date(req.query.hasta) : new Date();
  const desde = req.query.desde ? new Date(req.query.desde) : new Date(hasta.getTime() - 7 * 864e5);
  // incluir todo el día "hasta"
  const finExclusivo = new Date(hasta); finExclusivo.setHours(23, 59, 59, 999);
  return { desde, hasta: finExclusivo };
}

// ============ Estado de flota (derivado de switch) ============
// switch=false -> EN SERVICIO (activo).  switch=true -> FUERA DE SERVICIO.
exports.resumenFlota = asyncHandler(async (req, res) => {
  const vehiculos = await prisma.vehiculo.findMany();
  const data = await Promise.all(vehiculos.map(async (v) => {
    const t = await prisma.telemetria.findFirst({
      where: { vehiculoCodigo: v.codigo }, orderBy: { createdAt: 'desc' },
    });
    let operativo = 'SIN_DATOS';
    if (v.estadoAdmin === 'BAJA') operativo = 'BAJA';
    else if (t?.switch === false) operativo = 'EN_SERVICIO';
    else if (t?.switch === true) operativo = 'FUERA_SERVICIO';
    return { vehiculo: v, switch: t?.switch ?? null, operativo, ultimaLectura: t?.createdAt ?? null };
  }));
  const cuenta = (estado) => data.filter((d) => d.operativo === estado).length;
  res.json({
    vehiculos: data,
    totales: {
      total: data.length,
      enServicio: cuenta('EN_SERVICIO'),
      fueraServicio: cuenta('FUERA_SERVICIO'),
      baja: cuenta('BAJA'),
    },
  });
});

// ============ Km recorridos (suma de todos los equipos por día) ============
exports.kmRecorridos = asyncHandler(async (req, res) => {
  const { desde, hasta } = rango(req);
  const filas = await prisma.$queryRaw`
    SELECT date_trunc('day', created_at) AS dia, vehiculo_id,
           MAX(odometro_km) - MIN(odometro_km) AS km
    FROM telemetria
    WHERE created_at BETWEEN ${desde} AND ${hasta} AND odometro_km IS NOT NULL
    GROUP BY dia, vehiculo_id ORDER BY dia`;
  const porDia = new Map();
  for (const f of filas) {
    const k = f.dia.toISOString().slice(0, 10);
    porDia.set(k, (porDia.get(k) || 0) + Number(f.km || 0));
  }
  const serie = [...porDia.entries()].map(([dia, valor]) => ({ dia, valor: Math.round(valor * 100) / 100 }));
  const total = serie.reduce((a, b) => a + b.valor, 0);
  res.json({ serie, total: Math.round(total), unidad: 'km' });
});

// ============ Combustible consumido (por día, en litros si hay tanque) ============
exports.combustibleConsumido = asyncHandler(async (req, res) => {
  const { desde, hasta } = rango(req);
  const filas = await prisma.$queryRaw`
    WITH ordenado AS (
      SELECT t.created_at, t.nivel_combustible,
             LAG(t.nivel_combustible) OVER (PARTITION BY t.vehiculo_id ORDER BY t.created_at) AS prev,
             v.capacidad_tanque AS tanque
      FROM telemetria t
      JOIN vehiculos v ON v.codigo = t.vehiculo_id
      WHERE t.created_at BETWEEN ${desde} AND ${hasta} AND t.nivel_combustible IS NOT NULL
    )
    SELECT date_trunc('day', created_at) AS dia,
           SUM(GREATEST(prev - nivel_combustible, 0) / 100.0 * COALESCE(tanque, 0)) AS litros,
           SUM(GREATEST(prev - nivel_combustible, 0)) AS pct
    FROM ordenado GROUP BY dia ORDER BY dia`;
  const tieneLitros = filas.some((f) => Number(f.litros) > 0);
  const serie = filas.map((f) => ({
    dia: f.dia.toISOString().slice(0, 10),
    valor: Math.round((tieneLitros ? Number(f.litros) : Number(f.pct)) * 10) / 10,
  }));
  const total = serie.reduce((a, b) => a + b.valor, 0);
  res.json({ serie, total: Math.round(total), unidad: tieneLitros ? 'lts' : '%' });
});

// ============ Uso de equipo por día (movimiento / ralentí / apagado) ============
exports.usoEquipo = asyncHandler(async (req, res) => {
  const { desde, hasta } = rango(req);
  const filas = await prisma.$queryRaw`
    SELECT date_trunc('day', created_at) AS dia,
           MAX(horas_motor) - MIN(horas_motor) AS motor,
           MAX(horas_ralenti) - MIN(horas_ralenti) AS ralenti
    FROM telemetria
    WHERE vehiculo_id = ${req.params.codigo} AND created_at BETWEEN ${desde} AND ${hasta}
    GROUP BY dia ORDER BY dia`;
  const serie = filas.map((f) => {
    const motor = Math.min(Math.max(Number(f.motor || 0), 0), 24);
    const ralenti = Math.min(Math.max(Number(f.ralenti || 0), 0), motor);
    const movimiento = Math.max(motor - ralenti, 0);
    const apagado = Math.max(24 - motor, 0);
    return {
      dia: f.dia.toISOString().slice(0, 10),
      movimiento: +movimiento.toFixed(1), ralenti: +ralenti.toFixed(1), apagado: +apagado.toFixed(1),
    };
  });
  res.json({ serie });
});

// ============ Motor encendido por día (horas) ============
exports.motorEncendido = asyncHandler(async (req, res) => {
  const { desde, hasta } = rango(req);
  const filas = await prisma.$queryRaw`
    SELECT date_trunc('day', created_at) AS dia,
           MAX(horas_motor) - MIN(horas_motor) AS motor
    FROM telemetria
    WHERE vehiculo_id = ${req.params.codigo} AND created_at BETWEEN ${desde} AND ${hasta}
    GROUP BY dia ORDER BY dia`;
  const serie = filas.map((f) => ({
    dia: f.dia.toISOString().slice(0, 10),
    valor: +Math.min(Math.max(Number(f.motor || 0), 0), 24).toFixed(1),
  }));
  res.json({ serie, unidad: 'h' });
});

// ============ Próximos mantenimientos (calculado desde planes + telemetría) ============
const DIAS_POR_UNIDAD = { Dias: 1, Semanas: 7, Meses: 30, Anos: 365 };

async function promedioDiario(codigo) {
  const hace30 = new Date(Date.now() - 30 * 864e5);
  const t = await prisma.telemetria.findMany({
    where: { vehiculoCodigo: codigo, createdAt: { gte: hace30 } }, orderBy: { createdAt: 'asc' },
  });
  if (t.length < 2) return { kmDia: 0, horasDia: 0, odo: t[0]?.odometroKm ?? null, horo: t[0]?.horasMotor ?? null };
  const pri = t[0], ult = t[t.length - 1];
  const dias = Math.max((ult.createdAt - pri.createdAt) / 864e5, 1);
  return {
    kmDia: Math.max(((ult.odometroKm ?? 0) - (pri.odometroKm ?? 0)) / dias, 0),
    horasDia: Math.max(((ult.horasMotor ?? 0) - (pri.horasMotor ?? 0)) / dias, 0),
    odo: ult.odometroKm, horo: ult.horasMotor,
  };
}

exports.proximosMantenimientos = asyncHandler(async (req, res) => {
  const planes = await prisma.planMantenimiento.findMany({
    where: { activo: true }, include: { vehiculo: true },
  });
  const cache = {};
  const resultado = [];

  for (const p of planes) {
    const cod = p.vehiculo.codigo;
    if (!cache[cod]) cache[cod] = await promedioDiario(cod);
    const u = cache[cod];
    const candidatos = []; // fechas estimadas de cada criterio

    if (p.intervaloDias && p.baseFecha) {
      const dias = p.intervaloDias * (DIAS_POR_UNIDAD[p.unidadTiempo] || 1);
      candidatos.push(new Date(new Date(p.baseFecha).getTime() + dias * 864e5));
    }
    if (p.intervaloOdometro && u.odo != null && u.kmDia > 0) {
      const restante = (p.baseOdometro ?? u.odo) + p.intervaloOdometro - u.odo;
      candidatos.push(new Date(Date.now() + (restante / u.kmDia) * 864e5));
    }
    if (p.intervaloHorometro && u.horo != null && u.horasDia > 0) {
      const restante = (p.baseHorometro ?? u.horo) + p.intervaloHorometro - u.horo;
      candidatos.push(new Date(Date.now() + (restante / u.horasDia) * 864e5));
    }
    // "lo que ocurra primero" -> la fecha más cercana
    const fecha = candidatos.length ? new Date(Math.min(...candidatos.map((d) => d.getTime()))) : null;
    resultado.push({
      id: p.id, vehiculoId: p.vehiculoId, placa: p.vehiculo.placa || p.vehiculo.codigo,
      codigo: cod, nombre: p.nombre, urgencia: p.nivelUrgencia,
      fechaEstimada: fecha, vencido: fecha ? fecha < new Date() : false,
    });
  }
  resultado.sort((a, b) => {
    if (!a.fechaEstimada) return 1;
    if (!b.fechaEstimada) return -1;
    return a.fechaEstimada - b.fechaEstimada;
  });
  res.json(resultado.slice(0, Number(req.query.limite) || 10));
});
