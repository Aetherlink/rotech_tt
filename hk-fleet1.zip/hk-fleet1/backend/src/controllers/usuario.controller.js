const bcrypt = require('bcryptjs');
const { z } = require('zod');
const prisma = require('../config/prisma');
const { asyncHandler } = require('../middleware/error');

const crearSchema = z.object({
  email: z.string().email(),
  nombre: z.string().min(1),
  password: z.string().min(6, 'Mínimo 6 caracteres'),
  rol: z.enum(['ADMIN', 'SUPERVISOR', 'OPERADOR']),
  activo: z.boolean().optional(),
});
const editarSchema = z.object({
  nombre: z.string().min(1).optional(),
  rol: z.enum(['ADMIN', 'SUPERVISOR', 'OPERADOR']).optional(),
  activo: z.boolean().optional(),
  password: z.string().min(6).optional(),
});

const sinPass = { id: true, email: true, nombre: true, rol: true, activo: true, createdAt: true };

exports.listar = asyncHandler(async (req, res) => {
  res.json(await prisma.usuario.findMany({ select: sinPass, orderBy: { createdAt: 'asc' } }));
});

exports.crear = asyncHandler(async (req, res) => {
  const data = crearSchema.parse(req.body);
  data.password = await bcrypt.hash(data.password, 10);
  const usuario = await prisma.usuario.create({ data, select: sinPass });
  res.status(201).json(usuario);
});

exports.actualizar = asyncHandler(async (req, res) => {
  const data = editarSchema.parse(req.body);
  if (data.password) data.password = await bcrypt.hash(data.password, 10);
  const usuario = await prisma.usuario.update({
    where: { id: Number(req.params.id) }, data, select: sinPass,
  });
  res.json(usuario);
});

exports.eliminar = asyncHandler(async (req, res) => {
  if (Number(req.params.id) === req.usuario.id) {
    return res.status(400).json({ error: 'No puedes eliminar tu propio usuario' });
  }
  await prisma.usuario.delete({ where: { id: Number(req.params.id) } });
  res.status(204).end();
});
