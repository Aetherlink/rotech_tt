const prisma = require('../config/prisma');
const { asyncHandler } = require('../middleware/error');

// Columnas tipadas conocidas. El resto vive en metrics (JSONB).
const COLUMNAS = ['odometro_km', 'nivel_combustible', 'horas_ralenti', 'horas_motor', 'temperatura_refrigerante', 'switch'];
const MAP = {
  odometro_km: 'odometroKm', nivel_combustible: 'nivelCombustible', horas_ralenti: 'horasRalenti',
  horas_motor: 'horasMotor', temperatura_refrigerante: 'temperaturaRefrigerante', switch: 'switch',
};

// Aplana un registro a { clave: valor } unificando columnas + JSONB.
// Así el frontend no necesita saber DÓNDE está guardada cada señal.
function aplanar(t) {
  const out = { id: t.id, vehiculo: t.vehiculoCodigo, createdAt: t.createdAt };
  for (const c of COLUMNAS) out[c] = t[MAP[c]];
  if (t.metrics && typeof t.metrics === 'object') Object.assign(out, t.metrics);
  return out;
}

// Último valor por vehículo (para tarjetas del dashboard)
exports.ultimo = asyncHandler(async (req, res) => {
  const t = await prisma.telemetria.findFirst({
    where: { vehiculoCodigo: req.params.codigo },
    orderBy: { createdAt: 'desc' },
  });
  if (!t) return res.status(404).json({ error: 'Sin telemetría para este vehículo' });
  res.json(aplanar(t));
});

// Serie temporal de UNA señal (para gráficos). Funciona con cualquier señal,
// esté en columna o en el JSON metrics.
exports.serie = asyncHandler(async (req, res) => {
  const { codigo } = req.params;
  const clave = req.query.senal;
  const limite = Math.min(Number(req.query.limite) || 200, 2000);
  if (!clave) return res.status(400).json({ error: 'Parámetro "senal" requerido' });

  const registros = await prisma.telemetria.findMany({
    where: { vehiculoCodigo: codigo },
    orderBy: { createdAt: 'desc' },
    take: limite,
  });
  const serie = registros.reverse().map((t) => {
    const flat = aplanar(t);
    return { t: t.createdAt, v: flat[clave] ?? null };
  });
  res.json({ senal: clave, serie });
});

// Snapshot del dashboard: último valor de TODOS los vehículos
exports.resumenFlota = asyncHandler(async (req, res) => {
  const vehiculos = await prisma.vehiculo.findMany();
  const data = await Promise.all(vehiculos.map(async (v) => {
    const t = await prisma.telemetria.findFirst({
      where: { vehiculoCodigo: v.codigo }, orderBy: { createdAt: 'desc' },
    });
    return { vehiculo: v, telemetria: t ? aplanar(t) : null };
  }));
  res.json(data);
});

// Ingesta (por si quieres mandar desde Node-RED vía HTTP en lugar de SQL directo)
exports.ingestar = asyncHandler(async (req, res) => {
  const { vehiculo, ...resto } = req.body;
  if (!vehiculo) return res.status(400).json({ error: 'Campo "vehiculo" requerido' });
  const data = { vehiculoCodigo: vehiculo, metrics: {} };
  for (const [k, val] of Object.entries(resto)) {
    if (MAP[k]) data[MAP[k]] = val;        // señal conocida -> columna
    else data.metrics[k] = val;            // señal nueva -> JSONB
  }
  const creado = await prisma.telemetria.create({ data });
  res.status(201).json({ id: creado.id.toString() });
});
