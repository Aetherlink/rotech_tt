const { z } = require('zod');
const prisma = require('../config/prisma');
const { asyncHandler } = require('../middleware/error');

const materialSchema = z.object({
  nombre: z.string(), tipo: z.string().nullable().optional(),
  cantidad: z.number().nullable().optional(), unidad: z.string().optional(),
  observacion: z.string().optional(),
});

const schema = z.object({
  vehiculoId: z.number().int(),
  nombre: z.string().min(1),
  categoria: z.string().min(1),
  descripcion: z.string().optional().nullable(),
  requiereDetenerEquipo: z.boolean().optional(),
  requiereEspecialista: z.boolean().optional(),
  tipoPeriodicidad: z.enum(['HOROMETRO', 'ODOMETRO', 'TIEMPO', 'ODOMETRO_TIEMPO', 'HOROMETRO_TIEMPO']),
  intervaloHorometro: z.number().optional().nullable(),
  intervaloOdometro: z.number().optional().nullable(),
  intervaloDias: z.number().int().optional().nullable(),
  unidadTiempo: z.string().optional().nullable(),
  alertaHorometro: z.number().optional().nullable(),
  alertaOdometro: z.number().optional().nullable(),
  alertaDias: z.number().int().optional().nullable(),
  nivelUrgencia: z.enum(['BAJA', 'MEDIA', 'ALTA', 'CRITICA']).optional(),
  tiempoEstimado: z.number().optional().nullable(),
  unidadTiempoEstimado: z.string().optional().nullable(),
  personalRequerido: z.number().int().optional().nullable(),
  perfilPersonal: z.string().optional().nullable(),
  materiales: z.array(materialSchema).optional(),
  pasos: z.string().optional().nullable(),
  observaciones: z.string().optional().nullable(),
  activo: z.boolean().optional(),
});

// Al crear/editar, fija la línea base (lectura actual) para calcular vencimientos.
async function lineaBase(vehiculoId) {
  const v = await prisma.vehiculo.findUnique({ where: { id: vehiculoId } });
  if (!v) return {};
  const t = await prisma.telemetria.findFirst({
    where: { vehiculoCodigo: v.codigo }, orderBy: { createdAt: 'desc' },
  });
  return { baseFecha: new Date(), baseOdometro: t?.odometroKm ?? null, baseHorometro: t?.horasMotor ?? null };
}

exports.listar = asyncHandler(async (req, res) => {
  const where = req.query.vehiculoId ? { vehiculoId: Number(req.query.vehiculoId) } : {};
  const planes = await prisma.planMantenimiento.findMany({
    where, include: { vehiculo: { select: { codigo: true, placa: true } } }, orderBy: { createdAt: 'desc' },
  });
  res.json(planes);
});

exports.obtener = asyncHandler(async (req, res) => {
  const plan = await prisma.planMantenimiento.findUnique({
    where: { id: Number(req.params.id) }, include: { vehiculo: true },
  });
  if (!plan) return res.status(404).json({ error: 'Plan no encontrado' });
  res.json(plan);
});

exports.crear = asyncHandler(async (req, res) => {
  const data = schema.parse(req.body);
  const base = await lineaBase(data.vehiculoId);
  const plan = await prisma.planMantenimiento.create({ data: { ...data, ...base } });
  res.status(201).json(plan);
});

exports.actualizar = asyncHandler(async (req, res) => {
  const data = schema.partial().parse(req.body);
  const plan = await prisma.planMantenimiento.update({ where: { id: Number(req.params.id) }, data });
  res.json(plan);
});

// Marca el plan como ejecutado: reinicia la línea base a la lectura actual.
exports.registrarEjecucion = asyncHandler(async (req, res) => {
  const plan = await prisma.planMantenimiento.findUnique({ where: { id: Number(req.params.id) } });
  if (!plan) return res.status(404).json({ error: 'Plan no encontrado' });
  const base = await lineaBase(plan.vehiculoId);
  const actualizado = await prisma.planMantenimiento.update({ where: { id: plan.id }, data: base });
  res.json(actualizado);
});

exports.eliminar = asyncHandler(async (req, res) => {
  await prisma.planMantenimiento.delete({ where: { id: Number(req.params.id) } });
  res.status(204).end();
});
