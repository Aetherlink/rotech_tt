function asyncHandler(fn) {
  return (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);
}

function errorHandler(err, req, res, next) {
  console.error(err);
  if (err.name === 'ZodError') {
    return res.status(400).json({ error: 'Datos inválidos', detalles: err.errors });
  }
  if (err.code === 'P2002') {
    return res.status(409).json({ error: 'Registro duplicado', campo: err.meta?.target });
  }
  if (err.code === 'P2025') {
    return res.status(404).json({ error: 'Registro no encontrado' });
  }
  res.status(err.status || 500).json({ error: err.message || 'Error interno del servidor' });
}
module.exports = { asyncHandler, errorHandler };
