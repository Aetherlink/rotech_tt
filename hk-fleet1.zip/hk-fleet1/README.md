# HK Fleet — Monitoreo de flota (telemetría ECU)

Dashboard profesional para tus camiones HK. La telemetría llega por MQTT → Node-RED →
PostgreSQL, y esta app la expone con un API seguro y un frontend estilo *Modernize*.

**Stack:** Vue 3 + Vuetify · Node.js + Express · PostgreSQL · Prisma · JWT.
Todo de uso libre y sin costo.

## La decisión de arquitectura más importante

Tu requisito es "estar listo para 20 señales más". La solución es que **las señales son
datos, no código**:

- La tabla `senales` describe cada métrica (clave, etiqueta, unidad, ícono, color, umbral…).
- La telemetría guarda las señales conocidas en columnas tipadas (compatible con tu flujo
  actual) **y todo lo nuevo en una columna JSONB `metrics`**.
- El frontend lee `senales` y se pinta solo: cada señal activa genera su tarjeta y su gráfico.

**Agregar una señal nueva = crear una fila en la pantalla "Señales" + que el ECU la mande con
esa misma clave. Cero migraciones, cero código nuevo.**

## Requisitos

- **Node.js 24 LTS** (recomendado). Verifica con `node --version`. Instálalo con
  [nvm](https://github.com/nvm-sh/nvm): `nvm install 24 && nvm use 24`.
- PostgreSQL 14+ (o usa el `docker-compose.yml` incluido).

## Puesta en marcha (desarrollo)

### 1. Base de datos
```bash
# Opción rápida con Docker:
docker compose up -d
# …o usa tu Postgres existente y ajusta DATABASE_URL en backend/.env
```

### 2. Backend
```bash
cd backend
cp .env.example .env          # edita DATABASE_URL y JWT_SECRET
npm install
npm run generate              # genera el cliente Prisma
npm run migrate               # crea las tablas (te pedirá un nombre, ej: "init")
npm run seed                  # usuario admin + catálogo de señales + vehículo demo
npm run dev                   # API en http://localhost:3000
```
Login de prueba: **admin@hkfleet.com / admin123** (cámbialo en producción).

### 3. Frontend
```bash
cd frontend
cp .env.example .env          # VITE_API_URL=http://localhost:3000/api
npm install
npm run dev                   # app en http://localhost:5173
```

## Despliegue en servidor (resumen)

1. Backend: `npm install --omit=dev`, `npm run generate`, `npx prisma migrate deploy`,
   y córrelo con **PM2** (`pm2 start src/index.js --name hkfleet-api`).
2. Frontend: `npm run build` genera `dist/`. Sírvelo con **Nginx** y haz *reverse proxy*
   de `/api` hacia el backend.
3. HTTPS con Let's Encrypt (Certbot). Pon `CORS_ORIGIN` con tu dominio real.

## Conectar tu Node-RED
Ver `nodered-ejemplo.md`. Puedes seguir escribiendo a Postgres directo o pasar al endpoint
`POST /api/telemetria/ingest`.

## Estructura
```
backend/   API Express + Prisma (auth, vehiculos, mantenimientos, senales, telemetria)
frontend/  Vue 3 + Vuetify (dashboard, detalle, formularios, gestión de señales)
```

## Cómo extender (plantillas)
- **Nueva señal del ECU** → pantalla *Señales* → "Nueva señal" con la clave que envía el device.
- **Nueva pantalla/módulo** → copia un view de `src/views`, agrégalo al router y al menú del layout.
- **Nuevo componente de visualización** → los componentes `SignalCard` y `TrendChart` ya son
  genéricos; crea variantes (gauge, semáforo, mapa) siguiendo el mismo patrón de recibir
  `senal` + valor.
